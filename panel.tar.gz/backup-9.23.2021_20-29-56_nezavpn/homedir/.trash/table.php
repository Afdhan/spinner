<?php
session_start();
ob_flush();

include "con.php";

    $qry=mysqli_query("$db, CREATE TABLE templates(
    id_templates INT(3)  AUTO_INCREMENT PRIMARY KEY,
    nama_templates VARCHAR(100) NOT NULL,
    pembuat VARCHAR(100) NOT NULL,
    folder VARCHAR(100) NOT NULL)");
    if ($qry){
    echo "Table Templates Berhasil Dibuat";
    }else{
    echo "Gagal";
    }
?>