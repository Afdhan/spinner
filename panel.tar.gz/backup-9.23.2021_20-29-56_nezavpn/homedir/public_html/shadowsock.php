  <?php
  session_start();
  ob_flush();
  include "con.php";
  include "head.php";
  $email = mysqli_real_escape_string($db,  $_SESSION["email"]);
  if(empty($email)){
    echo ' <meta http-equiv="refresh" 
   content="0; url = index.php"/>  ';
    
  }
  $query = "select * from user where email='$email'";
   $hasil = mysqli_query($db, $query);
   $data = mysqli_fetch_assoc($hasil);
   $langganan = $data["max_acc"];
   if($langganan == 0){
     echo '<script> window.alert("Top Up Dulu Boss")
     </script>';
     echo ' <meta http-equiv="refresh" 
 content="0; url = dashboard.php"/>  ';
     
  //  header("Location: index.php");
     
   }
   
   $query = "select * from server";
   $hasil = mysqli_query($db,$query);
  
   
  ?>
<form method="post"> <div class="form-group"> <label for="exampleInputEmail1">Password</label> <input type="text" name="username" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Password Shadowsocks"> <small id="emailHelp" class="form-text text-muted"> Tidak Boleh Menggunakan (simbol: #\/@!%)</small> </div> <br>
 
    Masa Aktif
<p> 
   <select class="form-control" name="aktif">
       <option value="30" selected>30 Hari</option> 
        <option value="1">Trial</option>
   </select>
   </p>
   
   Server
<p> 
   <select class="form-control" name="server">
    <?php
    foreach($hasil as $data){
      $id = $data["id"];
      $lok = $data["location"];
      echo '<option value="'.$id.'"> '.$lok.' </option>';
    }
    ?>
     
   </select>
   </p>
<input type="submit" name="submit" class="btn btn-primary"> </form>
  

  
  <?php
  
  $pass = mysqli_real_escape_string($db, $_POST["username"]);
  $server = mysqli_real_escape_string($db, $_POST["server"]);
  $aktif = mysqli_real_escape_string($db, $_POST["aktif"]);
  
  if(empty($_POST["submit"])){
    echo '<div class="alert alert-success" role="alert"> Masukan Data Akun Shadowsocks</div>';
  
  }elseif(empty($pass)){
    echo '<div class="alert alert-success" role="alert"> Password Tidak Boleh Kosong!</div>';
  
  }else{
    $query = "select * from server where id='$server'";
  $hasil = mysqli_query($db, $query);
  $data = mysqli_fetch_assoc($hasil);
  $ip = $data["ip"];
  $pw = $data["password"];
  $user = $data["username"];
    
  
  set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib');
  include "File/ANSI.php";
  include('Net/SSH2.php');
  
  
  $host= $ip; 
  $root_password= $pw; 
  $ssh = new Net_SSH2($host);
  if (!$ssh->login($user, $root_password)) {
    die("login gagal");
    }
    
    
    
  $ansi = new File_ANSI(); 
  $ssh->write("sudo su\n");
 // $ssh->write("menu\n");
//  $ssh->write("5\n");
 // $ssh->read();
//  $ssh->write("2\n");
  $ssh->write("add-ss\n");
  $ssh->read();
  $ssh->write("$pass\n");
  $ssh->write("$aktif\n");
  $ansi->appendString($ssh->read("")); 
  $anu = $ansi->getHistory();
   
   
  if(preg_match("/Nama User Sudah Ada/", $anu)){
    echo '<div class="alert alert-success" role="alert"> Password Sudah Digunakan!</div>';
  
  }else{
echo '<div class="alert alert-success" role="alert"> Akun Shadowsocks Berhasil Dibuat!</div>';
$anu = str_replace("\n", "<br>",strip_tags($anu));
    if ($aktif == 30) {
      $acc = $langganan - 1;
      $query = "update user set max_acc='$acc' where email='$email'";
      mysqli_query($db, $query);
     }
      $has = substr($anu, 377, -21);
echo '<div class="alert alert-success" role="alert"> '.$has.'</div>';
  
  //  $query = "update user set max_acc='$acc' where email='$email'";
 //   mysqli_query($db, $query);
    
    
    
    $tgl= date("d-m-Y"); 
    $sebulan= mktime(0,0,0,date("n"),date("j")+$aktif,date("Y")); 
    $exp = date("d-m-Y", $sebulan); 
  
    
    
   $query = "insert into tunneling (id, oleh, tgl_dibuat, tgl_habis, deskripsi, type) values (null, '$email', '$tgl', '$exp', '$has', 'Shadowsocks')";
   mysqli_query($db, $query);
   
  }
  
  }
  include "foot.php";
  ?>