 <?php
  session_start();
  ob_flush();
  include "con.php";
 if(empty($_SESSION["email"])){
  
    echo ' <meta http-equiv="refresh" 
content="0; url = index.php"/>  ';
}
  ?>
  
  <!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="DhansProject">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">

    <title>Belajar Web </title>


   <link href="https://afdhan.github.io/sce/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/fontawesome.css">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/begrond.css">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/owl.css">
  </head>
  <body>
  
     <footer>
         	
    
             <center>
                 <form method="post">
           <div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
      <div class="dev"></div> 

              <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Server</font></th>
<td><font color="white">Amazon</font></td>
</tr>
<tr>
<th><font color="white">Host</font></th>
<td><font color="white">aws.dhans-project.xyz</font></td>
</tr>
<tr>
<th><font color="white">TLS</font></font></th>
<td><font color="white">8443</font></td> 
</tr>
  <tr>
<th><font color="white">HTTP</font></font></th>
<td><font color="white">80</font></td> 
</tr>
  
 </tbody>
</table>
<div class="dev"></div> 

<input type="text" name="username" class="form-control" placeholder="Remarks" autofocus></input>
  <div class="dev"></div> 
              <input type="submit" name="submit" class="btn btn-primary"> </form>
            </div>
          </div></form>
  
  
  
  <?php
  $username = mysqli_real_escape_string($db, $_POST["username"]);
 // $server =  mysqli_real_escape_string($db, $_POST["server"]);
 // $aktif = mysqli_real_escape_string($db,$_POST["aktif"]);
  
  if(empty($_POST["submit"])){
   
  
  }elseif(empty($username)){
   echo '<div class="col-md-12">
          <div class="sub-footer"></div></div><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item"><font color="white">Remarks Tidak Boleh Kosong!</font></div></div>';
  
  }else{
   // $query = "select * from server where id='$server'";
 // $hasil = mysqli_query($db, $query);
 // $data = mysqli_fetch_assoc($hasil);
  $ip= "54.151.255.30"; 
  $pw = "dhanss";
  $user = "root";
    
    
  
  set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib');
  include "File/ANSI.php";
  include('Net/SSH2.php');
  
  
  $host= $ip; 
  $root_password= $pw; 
  $ssh = new Net_SSH2($host);
  if (!$ssh->login($user, $root_password)) {
    die("login gagal");
    }
    
  $ansi = new File_ANSI(); 
  $ssh->write("sudo su\n");
  $ssh->write("add-ws\n");
  $ssh->write("$username\n");
  $ssh->write("3\n");
  $ssh->read();
  $ssh->write("cat /etc/v2ray/$username-tls.json\n");
 // $ssh->write("cat /etc/v2ray/$username-none.json\n");
  $ansi->appendString($ssh->read("")); 
  $anu = $ansi->getHistory();
   
  if(preg_match("/Nama User Sudah Ada/", $anu)){
   echo '<div class="col-md-12">
          <div class="sub-footer"></div></div><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item"><font color="white">Remarks Sudah Digunakan!</font></div></div>';
  
  }else{

    
   $anu = str_replace("\n", "<br>", strip_tags($anu));
    $link =  str_replace("<br>", "", strip_tags($anu));
    $lonk = str_replace("&quot;", "\"",  strip_tags($link));
    $tlss = strpos($lonk, "{");
    $yed = strpos($lonk, "}");
      $tls = substr($lonk, $tlss, -20);
     
    $nyet = str_replace("\"8443\"", "\"80\"", strip_tags($tls));
    $none = str_replace("\"tls\": \"tls\"", "\"tls\": \"none\"", strip_tags($nyet));
       $sebulan= mktime(0,0,0,date("n"),date("j")+3,date("Y")); 
    $exp = date("d-m-Y", $sebulan); 
  // echo $anu;
echo '<div class="col-md-12">
          <div class="sub-footer"></div></div>
    <center><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
             	<h4> Akun Berhasil Dibuat!</h4>
  <div class="dev"></div>
<table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Hostname</font></th>
<td><font color="white">aws.dhans-project.xyz</font></td>
</tr>
<tr>
<th><font color="white">Remarks</font></th>
<td><font color="white">'.$username.'</font></td>
</tr>
<tr>
<th><font color="white">Expired</font></th>
<td><font color="white">'.$exp.'</font></td> 
</tr>
</tbody>
</table>';
     // echo $jos;
     // echo '<br><div class="alert alert-primary" role="alert">';
   //  $uu = substr($has, $meki);
   //  $uuid = substr($uu, -$kiki);
    // echo $uuid;
   
    
        $link1 = base64_encode($tls);
        $link2 = base64_encode($none);
        //$web = base64_encode($has);
        //$link = substr($has, 529, -631);
       
        
  echo '<div class="dev"></div><center><fieldset>';
  echo '<textarea cols="20" rows="4" id="tls" readonly>vmess://'.$link1.'</textarea><br>';
 // echo '<textarea cols="20" rows="6" readonly>vmess://'.$link2.'</textarea>';
 echo '</fieldset></center> <br><center><p><button type="button" class="btn btn-primary" onclick="copy_tls()">Copy Link TLS</button></p>';


echo '<div class="dev"></div><center><fieldset>';
  echo '<textarea cols="20" rows="4" id="non" readonly>vmess://'.$link2.'</textarea><br>';
 // echo '<textarea cols="20" rows="6" readonly>vmess://'.$link2.'</textarea>';
 echo '</fieldset></center> <br><center><p><button type="button" class="btn btn-primary" onclick="copy_non()">Copy Link HTTP</button></p></div></div></center>
</div>';

   //$query = "insert into tunneling (id, oleh, tgl_dibuat, tgl_habis, deskripsi, type) values (null, '$email', '$tgl', '$exp', '$has', 'VMess')";
 //  mysqli_query($db, $query);
   
  }
  }
  ?>
   <div class="col-md-12">
          <div class="sub-footer">
              <p>Copyright 2021 | <a rel="nofollow" href="https://t.me/SobatGretong">DhanZaa Team</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    
  <script src="https://afdhan.github.io/sce/vendor/jquery/jquery.min.js"></script>
    <script src="https://afdhan.github.io/sce/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="https://afdhan.github.io/sce/assets/js/custom.js"></script>
    <script src="https://afdhan.github.io/sce/assets/js/owl.js"></script>
    <script src="https://afdhan.github.io/sce/assets/js/accordions.js"></script>
  <script type="text/javascript">
    function copy_tls() {
        document.getElementById("tls").select();
        document.execCommand("copy");
        alert("Link TLS Berhasil Dicopy Ke Clipboard!");
    }
    
     function copy_non() {
        document.getElementById("non").select();
        document.execCommand("copy");
        alert("Link HTTP Berhasil Dicopy Ke Clipboard!");
    }
</script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; 
      function clearField(t){ 
      if(! cleared[t.id]){ 
          cleared[t.id] = 1;  
          t.value=''; 
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>

 
