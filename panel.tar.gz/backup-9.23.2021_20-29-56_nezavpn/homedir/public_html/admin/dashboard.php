<?php
session_start();
ob_flush();
include "../con.php";
include "../head.php";
$sesi = $_SESSION["username"];
if(empty($sesi)){
  header("Location: /index.php");
}
$query= "select * from admin where password='$sesi'";
$hasil = mysqli_query($db, $query);
$anu = mysqli_fetch_assoc($hasil);
if($sesi =! $anu["password"]){
  echo ' <script> window.location.href("index.php"); </script>';
}

?>
 



<div class="card"> <h5 class="card-header">Selamat Datang Admin</h5> <div class="card-body"><p class="card-text">
  <li> <a href="vps.php"> Tambah VPS </a> </li>
    <li> <a href="saldo.php"> Tambah saldo </a> </li>
       <li> <a href="cangepass.php"> Ganti Password Admin </a> </li>
       <li><a href="ingfo.php">Kirim Pesan</a></li>
       <li> <a href="?hapus=1"> Hapus Pesan </a> </li>
       </div> </div> <br>
       

<?php
 
if(!empty($_GET["hapus"])){
  
   $query = "delete from info where id=1";
   if(mysqli_query($db, $query)){
    echo '<div class="alert alert-success" role="alert"> Berhasil Menghapus Pesan!</div>';
     echo ' <meta http-equiv="refresh" 
 content="5; url = dashboard.php"/>  ';
   }else {
       echo '<div class="alert alert-success" role="alert"> Gagal Menghapus Pesan!</div>';
        echo ' <meta http-equiv="refresh" 
 content="5; url = dashboard.php"/>  ';
   }

}




$query = "select * from user";
$hasil = mysqli_query($db, $query);

?>
<table class="table"> <thead> <tr> <th scope="col">ID </th> <th scope="col">Username</th> <th scope="col">E-Mail</th> <th scope="col">Limit</th> <th scope="col">Action</th> </th> </tr> </thead> <tbody>

<?php
while($data = mysqli_fetch_array($hasil)){
  
  $id = $data["id"];
  $user = $data["username"];
  $mail = $data["email"];
  $acc = $data["max_acc"];
echo '<tr> <th scope="row">'.$id.'</th> <td>'.$user.'</td> <td>'.$mail.' </td> <td>'.$acc.'</td><td><a href="?del='.$mail.'"> Hapus </a></td>  </tr>';

}
echo "</tbody> </table>";

if(!empty($_GET["del"])){
  $del = $_GET["del"];
   $query = "delete from user where email='$del'";
   if(mysqli_query($db, $query)){
     echo '<script> alert("Berhasil Menghapus User!");
     </script> ';
     echo ' <meta http-equiv="refresh" 
 content="0; url = dashboard.php"/>  ';
   }
  
}


include"../foot.php";
?>