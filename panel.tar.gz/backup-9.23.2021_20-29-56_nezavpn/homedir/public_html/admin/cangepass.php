<?php
session_start();
ob_flush();
include "../con.php";
include "../head.php";
$sesi = $_SESSION["username"];
if(empty($_SESSION["username"])){
  header("Location: dashboard.php");
}


?>

<form method="post" action="#">
 Password : 
  <p> <input type="password" name="password"></p>
  <p> <input type="submit" name="submit"></p>
</form>


<?php
$pass = $_POST["password"];
if(!empty($pass)){
  

$query = "update admin set password='$pass' where password='$sesi'";
$hasil = mysqli_query ($db, $query);
if($hasil){
  
  echo ' <script> alert("Password Berhasil Diupdate."); </script> ';

}else{
  
  echo ' <script> alert("Gagal update password"); </script> ';
}
}

?>