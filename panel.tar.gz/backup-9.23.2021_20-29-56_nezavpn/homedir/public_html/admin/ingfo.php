<?php
  session_start();
  ob_flush();
  include "../con.php";
  include "../head.php";

$sesi = $_SESSION["username"];
if(empty($sesi)){
  header("Location: /index.php");
}
$query= "select * from admin where password='$sesi'";
$hasil = mysqli_query($db, $query);
$anu = mysqli_fetch_assoc($hasil);
if($sesi =! $anu["password"]){
  echo ' <script> window.location.href("index.php"); </script>';
}


?>

<p> 
<form method="post"> <div class="form-group">
<label for="adm">  Nama Pengirim : </label>

   <select name="mimin" id="adm">
       <option value="NezaVPN">NezaVPN</option> 
        <option value="Dhansss">Dhansss</option>
   </select>
   </p><!--
 <label for="psn">Pesan :</label>-->
 <center>
 <fieldset>
         <textarea name="pesan" rows="5" id="psn" placeholder="Masukkan Pesan Disini..." autofocus="true"></textarea>
                    </fieldset>
    <input type="submit" name="submit" class="btn btn-primary">
                    </center></div></form><br>
<?php

  $admin = mysqli_real_escape_string($db, $_POST["mimin"]);
  $pesan = mysqli_real_escape_string($db,$_POST["pesan"]);
  
  if(empty($_POST["submit"])){
}else {
  $query = "insert into info(id, isi, dari) values ('1', '$pesan', '$admin')";
  $hasil = mysqli_query($db, $query);
  if ($hasil){
      echo '<div class="alert alert-success" role="alert"> Berhasil Mengirim Pesan</div>';
  }else {
      echo '<div class="alert alert-warning" role="alert"> Gagal Mengirim Pesan</div>';
  }
  
  
}
  
  
?>