<?php
session_start();
ob_flush();
include "head.php";
include "con.php";
if(!empty($_SESSION["email"])){
  
    echo ' <meta http-equiv="refresh" 
 content="0; url = dashboard.php"/>  ';
}


?>



<?php
$email = mysqli_real_escape_string($db,strtolower($_POST["email"]));
$username =mysqli_real_escape_string($db, $_POST["username"]);
$pass = mysqli_real_escape_string($db, $_POST["password"]);



if(empty($_POST["submit"])){
    
}elseif(!preg_match("/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/", $email)){
     echo '<script> window.alert("Email Tidak Valid!")
     </script>';
}elseif(strlen($pass) < 6){
  echo '<script> window.alert("Pasword Harus Lebih Dari 6 Karakter")
     </script>';
}else{
   $query = " select * from user where email='$email'";
   $hasil = mysqli_query($db, $query);
   
   if(mysqli_num_rows($hasil) > 0){
     echo '<script> window.alert("Email Sudah Digunakan!")
     </script>';
   }else{
 // $token = hash('sha256', md5($email));
  $query = "insert into user (id, username, email, password, max_acc) values (null, '$username', '$email', '$pass', 0)";
 
  
  
  $hasil = mysqli_query($db, $query);
  if($hasil){
  $message = "
  Assalamualaikum $username
  
  Selamat Bergabung Dengan Kami, Silahkan Aktifkan Akun Anda Dengan Mengklik Link Dibawah Ini
  
  Aktifasi : https://resselervpnku.tech/aktif.php?mail=$email
  
  Dhansss X NezaVPN
  
  ";
  $headers = 'From: DhanZaa Project <admin@resselervpnku.tech>';
  $subject = "RESELLER ACC";
  
    mail($email, $subject, $message, $headers);
    echo '<script> window.alert("Daftar Berhasil.")
     </script>';
     echo ' <meta http-equiv="refresh" 
 content="0; url = index.php"/>  ';
  }else{
   echo '<script> window.alert("Daftar Gagal. Database Error.")
     </script>';
  
  }
   } 
}
?>

<section class="h-100">		<div class="container h-100">			<div class="row justify-content-sm-center h-100">				<div class="col-xxl-4 col-xl-5 col-lg-5 col-md-7 col-sm-9">					<div class="text-center my-5">					 <!--	<img src="https://getbootstrap.com/docs/5.0/assets/brand/bootstrap-logo.svg" alt="logo" width="100"> -->
     </div>				<div class="card shadow-lg">						<div class="card-body p-5">							<h1 class="fs-4 card-title fw-bold mb-4"><center>REGISTER</center></h1>							<form method="POST" action="#" class="needs-validation" novalidate="" autocomplete="off">								<div class="mb-3">									<label class="mb-2 text-muted" for="name">Nama</label>									<input id="name" type="text" class="form-control" name="username" value="" required autofocus>									<div class="invalid-feedback">										Masukkan Nama										</div>								</div> 								<div class="mb-3">									<label class="mb-2 text-muted" for="email">Alamat E-Mail</label>									<input id="email" type="email" class="form-control" name="email" value="" required>									<div class="invalid-feedback">										Email Tidak Valid									</div>								</div> 								<div class="mb-3">									<label class="mb-2 text-muted" for="password">Password</label>									<input id="password" type="password" class="form-control" name="password" required>								 <div class="invalid-feedback">								 	Masukkan Password							 	</div>								</div> 								<p class="form-text text-muted mb-3">									Dengan Mengklik Tombol Daftar, Berarti Anda Menyetujui Syarat Dan Privasi Kami								</p>							<div class="align-items-center d-flex">									<input type="submit" name="submit" value="Daftar" class="btn btn-primary ms-auto">																	</div>							</form>						</div>						<div class="card-footer py-3 border-0">							<div class="text-center">								Sudah Punya Akun? <a href="index.php" class="text-dark">Login</a>							</div>						</div>					</div>				


<?php

include "foot.php";
?>