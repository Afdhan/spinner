<?php
session_start();
ob_flush();
include "../con.php";
include "../head.php";
$sesi = $_SESSION["username"];
if(!empty($_SESSION["username"])){
  header("Location: dashboard.php");
}

?>

<form method="post" action="#">
 Password : 
  <p> <input type="password" name="password"></p>
  <p> <input type="submit" name="submit"></p>
</form>

<?php
$pass = $_POST["password"];
if(!empty($pass)){
  

$query = "select * from admin where password='$pass'";
$hasil = mysqli_query ($db, $query);
if(mysqli_num_rows($hasil)>0){
  $_SESSION["username"] = "$pass";
  echo "Berhasil login, Masuk ke <a href='dashboard.php'> Dashboard </a>";
}else{
  
  echo ' <script> alert("Password salah."); </script> ';
}

}

include "../foot.php";
?>