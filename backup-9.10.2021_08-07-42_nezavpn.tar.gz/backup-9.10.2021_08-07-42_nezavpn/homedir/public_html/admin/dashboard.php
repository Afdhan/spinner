<?php
session_start();
ob_flush();
include "../con.php";
include "../head.php";
$sesi = $_SESSION["username"];
if(empty($sesi)){
  header("Location: /index.php");
}
$query= "select * from admin where password='$sesi'";
$hasil = mysqli_query($db, $query);
$anu = mysqli_fetch_assoc($hasil);
if($sesi =! $anu["password"]){
  echo ' <script> window.location.href("index.php"); </script>';
}
?>
 



<div class="card"> <h5 class="card-header">Selamat Datang Admin</h5> <div class="card-body"><p class="card-text">
  <li> <a href="vps.php"> Tambah VPS </a> </li>
    <li> <a href="saldo.php"> Tambah saldo </a> </li>
       <li> <a href="cangepass.php"> Ganti Password Admin </a> </li>
       </div> </div>




<?php






include"../foot.php";
?>