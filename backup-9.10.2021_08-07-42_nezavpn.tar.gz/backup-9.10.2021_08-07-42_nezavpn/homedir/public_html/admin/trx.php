<?php
include "../head.php";
include "../con.php";

$query = "select * from  tunneling order by id desc limit 10";
$hasil = mysqli_query($db, $query);
?>

<table class="table"> <thead> <tr> <th scope="col">ID </th> <th scope="col">Aktif</th> <th scope="col">Expired</th> <th scope="col">Type</th> </tr> </thead> <tbody></tbody>

<?php
while($data = mysqli_fetch_array($hasil)){
  
  
  $id= $data["id"];
  $buat = $data["tgl_dibuat"];
  $exp = $data["tgl_habis"];
  $typ = $data["type"];
  
echo '<tr> <th scope="row">'.$id.'</th> <td>'.$buat.'</td> <td>'.$exp.'</td> <td> '.$typ.' </td> </tr>';

}
echo "</tbody> </table>";

include "../foot.php";
?>