<?php
session_start();
ob_flush();
include"../con.php";
include"../head.php";
?>
<form method="post" action="#">
  IP : 
  <p><input type="text" name="ip"></p>
  Username :
  <p><input type="text" name="username"></p>
  Password:
  <p> <input type="password" name="password"></p>
Location : 
  <p><input type="text" name="location"></p>

  <p>
    
    <input type="submit" name="submit">
  </p>
</form>


<?php
$ip = mysqli_real_escape_string($db, $_POST["ip"]);
$user = mysqli_real_escape_string($db, $_POST["username"]);
$pass = mysqli_real_escape_string($db, $_POST["password"]);
$loc = mysqli_real_escape_string($db, $_POST["location"]);

if(!empty($ip ) && !empty($user) && !empty($pass) && !empty($loc)){
$query = "insert into server (id, ip, username,password,location) value(NULL, '$ip', '$user', '$pass', '$loc')";
$hasil = mysqli_query($db, $query);
if($hasil){
  echo '<script> alert("Data VPS Berhasil Disimpan Ke Database."); </script>';
}else{
  echo '<script> alert("Gagal Memasukan Data VPS Ke Database."); </script>';
}
}
$query = "select * from server limit 10";
$hasil = mysqli_query($db, $query);

?>
<table class="table"> <thead> <tr> <th scope="col">IP </th> <th scope="col">Username</th> <th scope="col">Password</th> <th scope="col">Action</th> </tr> </thead> <tbody></tbody>

<?php
while($data = mysqli_fetch_array($hasil)){
  
  $ip = $data["ip"];
  $user = $data["username"];
  $pass = $data["password"];
echo '<tr> <th scope="row">'.$ip.'</th> <td>'.$user.'</td> <td>'.$pass.' </td> <td><a href="?del='.$ip.'"> Delete </a></td> </tr>';

}
echo "</tbody> </table>";

if(!empty($_GET["del"])){
  $del = $_GET["del"];
   $query = "delete from server where ip='$del'";
   if(mysqli_query($db, $query)){
     echo '<script> alert("Hapus VPS Daru Database Berhasil.");
     window.location.href("vps.php");
     </script> ';
   }
  
}


include"../foot.php";
?>
