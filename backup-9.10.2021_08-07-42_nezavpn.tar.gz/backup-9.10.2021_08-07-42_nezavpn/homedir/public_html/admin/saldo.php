<?php
include "../con.php";
include "../head.php";

?>

Masukan email resseler.<br>
<form method="post" action="#">
  Email : 
  <p><input type="text" name="email"></p>
  Saldo :,
<p><input type="text" name="saldo"></p>
  <p>
    
    <input type="submit" name="submit">
  </p>
</form>





<?php
$email = mysqli_real_escape_string($db,strtolower($_POST["email"]));
$saldo = mysqli_real_escape_string($db,     $_POST["saldo"]);

if(!empty($email) && !empty($saldo)){
$query = "update user set max_acc='$saldo' where email='$email'";
if(mysqli_query($db, $query)){
  echo '<script> alert("Berhasil menambahkan saldo"); </script>';
}else{
echo '<script> alert("Gagal menambahkan saldo"); </script>';
}
}

include"../foot.php";
?>