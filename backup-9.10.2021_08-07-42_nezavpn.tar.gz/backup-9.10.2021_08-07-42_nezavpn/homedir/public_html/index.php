<?php
session_start();
ob_flush();
$title = "NEZAVPN_AFDHAN";
include "head.php";
include "con.php";
//if(empty($_COOKIE["login"])){
//    if($_COOKIE["login"] == 'true'){
  //      $_SESSION["email"] == $email;
//    }
//}

if(!empty($_SESSION["email"])){
  //  if(empty($_COOKIE["login"])){
  
    echo ' <meta http-equiv="refresh" 
 content="0; url = dashboard.php"/>  ';
//  }
}
?>






<?php
$email = mysqli_real_escape_string($db, strtolower($_POST["email"]));
$pass = mysqli_real_escape_string($db,$_POST["password"]);
if(empty($_POST["submit"])){
  
}else{
  $query = "select * from user where email='$email' and password='$pass'";
 $hasil = mysqli_query($db,$query);
  if(mysqli_num_rows($hasil) > 0){
    $_SESSION["email"] = $email;
   echo ' <meta http-equiv="refresh" 
 content="0; url = dashboard.php"/>  ';
//if(empty($_POST["remember"])) {
 //   setcookie('email', '.$email.');
//}
    echo '<script> window.alert("Login Berhasil!")
     </script>';
  }else{
  echo '<script> window.alert("Data Login Tidak Ditemukan!")
     </script>';  
  
  }
}


?>  
 	<section class="h-100"> 		<div class="container h-100"> 			<div class="row justify-content-sm-center h-100"> 				<div class="col-xxl-4 col-xl-5 col-lg-5 col-md-7 col-sm-9"> 					<div class="text-center my-5"> 					<!--	<img src="https://getbootstrap.com/docs/5.0/assets/brand/bootstrap-logo.svg" alt="logo" width="100"> -->					</div> 					<div class="card shadow-lg"> 						<div class="card-body p-5"> 							<h1 class="fs-4 card-title fw-bold mb-4"><center>LOGIN</center></h1> 							<form method="POST" class="needs-validation" novalidate="" autocomplete="off"> 								<div class="mb-3"> 									<label class="mb-2 text-muted" for="email">Alamat E-Mail</label> 									<input id="email" type="email" class="form-control" name="email" value="" required autofocus> 									<div class="invalid-feedback"> 										Email Tidak Valid 									</div> 								</div> 								<div class="mb-3"> 									<div class="mb-2 w-100"> 										<label class="text-muted" for="password">Password</label> 									<!--	<a href="forgot.html" class="float-end"> 											Lupa Password? 										</a> -->									</div> 									<input id="password" type="password" class="form-control" name="password" required> 								 <div class="invalid-feedback"> 								 	Masukkan Password  							 	</div> 								</div> 								<div class="d-flex align-items-center"> 									<div class="form-check"> 									<!--	<input type="checkbox" name="remember" id="remember" class="form-check-input"> 										<label for="remember" class="form-check-label">Ingat Saya</label>-->									</div> 								<input type="submit" name="submit" class="btn btn-primary ms-auto" value="Masuk"data-bs-toggle="modal" data-bs-target="#exampleModal">												</div> 							</form> 						</div> 						<div class="card-footer py-3 border-0"> 							<div class="text-center"> 								Belum Punya Akun? <a href="daftar.php" class="text-dark">Daftar</a> 							</div> 						</div> 					</div> 		
 	
 	
 	<?php
 	include "foot.php";
 	?>