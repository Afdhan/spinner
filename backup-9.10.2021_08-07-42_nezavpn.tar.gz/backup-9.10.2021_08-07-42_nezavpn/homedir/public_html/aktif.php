<?php
         session_start();
         ob_flush();
         include "con.php";

         $id = $_GET['id'];
         
        

        $query = " select * from user where id='$id'";
        $hasil = mysqli_query($db, $query);
        $data = mysqli_fetch_assoc($hasil);
         
         $ide = $data["id"];
        
         if ($edi != $id) {
             echo '<script> window.alert("Verifikasi Gagal! User ID Tidak Valid")
     </script>';
                echo ' <meta http-equiv="refresh" 
 content="0; url = daftar.php"/>  ';
         }else {
             echo '<script> window.alert("Verifikasi Berhasil! Silahkan Login")
     </script>';
                echo ' <meta http-equiv="refresh" 
 content="0; url = index.php"/>  ';
         }
    ?>