  <?php
  session_start();
  ob_flush();
  include "con.php";
  include "head.php";
  $email = $_SESSION["email"];
  if(empty($email)){
    echo ' <meta http-equiv="refresh" 
   content="0; url = index.php"/>  ';
    
  }
  $query = "select * from user where email='$email'";
   $hasil = mysqli_query($db, $query);
   $data = mysqli_fetch_assoc($hasil);
   $langganan = $data["max_acc"];
   if($langganan == 0){
     echo '<script> window.alert("Top Up Dulu Boss")
     </script>';
     echo ' <meta http-equiv="refresh" 
 content="0; url = dashboard.php"/>  ';
     
  //  header("Location: index.php");
     
   }
   
   $query = "select * from server";
   $hasil = mysqli_query($db,$query);
  
   
  ?>
<form method="post"> <div class="form-group"> <label for="exampleInputEmail1">Username</label> <input type="text" name="username" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Username SSH"> <small id="emailHelp" class="form-text text-muted"> Tidak Boleh Menggunakan (simbol: #\/@!%)</small> </div> <div class="form-group"> <label for="exampleInputPassword1">Password</label> <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password SSH"> </div> 
Server
<p> 
   <select class="form-control" name="server">
    <?php
    foreach($hasil as $data){
      $id = $data["id"];
      $lok = $data["location"];
      echo '<option value="'.$id.'"> '.$lok.' </option>';
    }
    ?>
     
   </select>
   </p>
<input type="submit" name="submit" class="btn btn-primary"> </form>
  

  
  
  
  
  <?php
  $username =mysqli_real_escape_string($db, strtolower($_POST["username"]));
  $pass = mysqli_real_escape_string($db, $_POST["password"]);
  $server = mysqli_real_escape_string($db,$_POST["server"]);
  
  if(!empty($username) && !empty($pass) && !empty($server)){
    $query = "select * from server where id='$server'";
  $hasil = mysqli_query($db, $query);
  $data = mysqli_fetch_assoc($hasil);
  $ip = $data["ip"];
  $pw = $data["password"];
  $user = $data["username"];
    
    if($username == $user){
     echo ' <script> alert("Username Sudah Digunakan."); 
     window.location.href("ssh.php");
     
     </script>';
     
     
    }
  set_include_path(get_include_path() . PATH_SEPARATOR . 'phpseclib');
  include "File/ANSI.php";
  include('Net/SSH2.php');
  
  
  $host= $ip; 
  $ssh = new Net_SSH2($host);
  if (!$ssh->login($user, $pw)) {
    die("login gagal");
    }
    
    
    
  $ansi = new File_ANSI(); 
  $ssh->write("sudo su\n");
 // $ssh->write("menu\n");
 // $ssh->write("1\n");
 // $ssh->read();
 // $ssh->write("1\n");
  $ssh->write("usernew\n");
  $ssh->read();
  $ssh->write("$username\n");
  $ssh->write("$pass\n");
  $ssh->write("30\n");
  $ansi->appendString($ssh->read("")); 
  $anu = $ansi->getHistory();
  
   
  if(preg_match("/already/", $anu)){
   // echo '<script> alert("Username sudah digunakan."); </script>';
  echo '<div class="alert alert-success" role="alert"> Username Sudah Digunakan!</div>';
   }else{
    echo '<div class="alert alert-success" role="alert"> Akun SSH & OVPN Berhasil Dibuat!</div>';
   $anu = str_replace("\n", "<br>", strip_tags($anu));
      $acc = $langganan - 1;
      
      echo '<p> <div class="alert alert-success" role="alert"> '.$anu.'</div> </p>';
    $query = "update user set max_acc='$acc' where email='$email'";
    mysqli_query($db, $query);
    
    
    
    $tgl= date("d-m-Y"); 
    $sebulan= mktime(0,0,0,date("n"),date("j")+30,date("Y")); 
    $exp = date("d-m-Y", $sebulan); 
  
    
    
   $query = "insert into tunneling (id, oleh, tgl_dibuat, tgl_habis, deskripsi, type) values (null, '$email', '$tgl', '$exp', '$anu', 'SSH')";
   mysqli_query($db, $query);
   
  }
  
  }
  include"foot.php";
  ?>