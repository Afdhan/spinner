<?php
session_start();
ob_flush();
include "head.php";
include "con.php";
if(empty($_SESSION["email"])){
  
    echo ' <meta http-equiv="refresh" 
 content="0; url = index.php"/>  ';
}
$email = mysqli_real_escape_string($db,$_SESSION["email"]);

$query = "select * from user where email='$email'";
$hasil = mysqli_query($db, $query);
$data = mysqli_fetch_assoc($hasil);
$username = $data["username"];
$email = $data["email"];
$acc = $data["max_acc"];
echo '<div class="card"> <h5 class="card-header">Selamat Datang '.$username.'</h5> <div class="card-body"> <h5 class="card-title">Informasi Akun</h5> <p class="card-text">
<li> Username : '.$username.' </li>
<li> Email : '.$email.' </li>
<li> Password : ******** </li>
<li> Limit Akun : '.$acc.' </li>


</p> <a href="top_up.html" class="btn btn-primary">Top Up</a> 
 <a href="logout.php" class="btn btn-primary">Logout</a> </div> </div>

';
?> 
<div class="card"> <h5 class="card-header">MENU LAYANAN</h5> <div class="card-body"><p class="card-text">
  <li> <a href="ssh.php"> Create SSH </a> </li>
    <li> <a href="sstp.php"> Create SSTP </a> </li>
    <li> <a href="wireguard.php"> Create Wireguard </a> </li>
      <li> <a href="ssr.php"> Create SSR </a> </li>
        <li> <a href="shadowsock.php"> Create Shadowsocks</a> </li>
          <li> <a href="pptp.php"> Create PPTP</a> </li> 
          <li> <a href="trojan.php"> Create Trojan </a> </li>
          <li> <a href="l2tp.php"> Create L2TP</a> </li>
            <li> <a href="vless.php"> Create VLess</a> </li>
           <li> <a href="vmess.php"> Create VMess</a> </li>

 
 </div> </div>




<?php

$query = "select * from tunneling where oleh='$email' order by id  desc limit 10";
$hasil = mysqli_query($db, $query);

echo '<table class="table"> <thead> <tr> <th scope="col">ID </th> <th scope="col">Type</th> <th scope="col">Expired</th> <th scope="col">Detail</th> </tr> </thead> <tbody></tbody>';

while($data = mysqli_fetch_array($hasil)){
 $star = $data["tgl_dibuat"];
 $exp = $data["tgl_habis"];
 $typ = $data["type"];
 $id = $data["id"];
 
 
echo '<tr> <th scope="row">'.$id.'</th> <td>'.$typ.'</td> <td>'.$exp.' </td> <td><a href="view.php?id='.$id.'"> View </a></td> </tr>';

}
 echo "</tbody> </table>";


include "foot.php";
?>