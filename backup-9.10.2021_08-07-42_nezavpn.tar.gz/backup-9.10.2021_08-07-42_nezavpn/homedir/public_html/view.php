<?php
session_start();
ob_flush();
include "con.php";
$email = $_SESSION["email"];
$id = $_GET["id"];
if(empty($id)){
  header("Location: index.php");
}
$query = " select * from tunneling where id='$id'";
$hasil = mysqli_query($db, $query);
$data = mysqli_fetch_assoc($hasil);
$oleh = $data["oleh"];
$acc = $data["deskripsi"];
if($email != $oleh){
  header("Location:index.php");
}else{
  
  echo $acc;
}
?>