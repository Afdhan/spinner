<?php
$dbhost = "localhost";

$dbname = "nezavpn_panel"; 

$dbuser = "nezavpn_panelku"; 

$dbpass = "panelku2709"; 

$db = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname); 

 if (!$db) { 
   die("Koneksi gagal");
   } 
   
   
   
   
