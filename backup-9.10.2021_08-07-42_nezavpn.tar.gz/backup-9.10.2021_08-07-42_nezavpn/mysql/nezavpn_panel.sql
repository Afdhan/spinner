-- MySQL dump 10.19  Distrib 10.3.30-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: nezavpn_panel
-- ------------------------------------------------------
-- Server version	10.3.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `nezavpn_panel`
--


--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `password`) VALUES (1,'root');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server`
--

DROP TABLE IF EXISTS `server`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(500) NOT NULL,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `location` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server`
--

LOCK TABLES `server` WRITE;
/*!40000 ALTER TABLE `server` DISABLE KEYS */;
INSERT INTO `server` (`id`, `ip`, `username`, `password`, `location`) VALUES (12,'34.87.14.238','root','nizamzahro','GCP Singapore'),(11,'34.101.183.39','root','nizamzahro','GCP Indonesia');
/*!40000 ALTER TABLE `server` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tunneling`
--

DROP TABLE IF EXISTS `tunneling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tunneling` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oleh` varchar(500) NOT NULL,
  `tgl_dibuat` varchar(500) NOT NULL,
  `tgl_habis` varchar(500) NOT NULL,
  `deskripsi` varchar(10000) NOT NULL,
  `type` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tunneling`
--

LOCK TABLES `tunneling` WRITE;
/*!40000 ALTER TABLE `tunneling` DISABLE KEYS */;
INSERT INTO `tunneling` (`id`, `oleh`, `tgl_dibuat`, `tgl_habis`, `deskripsi`, `type`) VALUES (1,'dhaay2709@gmail.com','05-09-2021','05-10-2021','\r<br>\r<br>\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\r<br>\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\r<br>\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\r<br>=================================\r<br> ~&gt; SSH &amp; OpenVPN\r<br>=================================\r<br> Username       : Gunimane \r<br> Password       : gunimane\r<br> Hostname       : ennt.nezavpn.my.id\r<br>=================================\r<br> ISP            : Google LLC\r<br> CITY           : Singapore\r<br> COUNTRY        : SG\r<br> Server IP      : 34.126.175.86\r<br> OpenSSH        : 22\r<br> Dropbear       : 109, 143\r<br> SSL/TLS        : 567, 171\r<br> WS Dropbear    : 8880\r<br> WS OpenSSH     : 2095\r<br> WS OpenVPN     : 2082\r<br> WS TLS         : 443\r<br> Squid          : 3128, 8080 (limit to IP SSH)\r<br> BadVPN         : 7100, 7200, 7300\r<br>=================================\r<br>~&gt; Configs OpenVPN\r<br>\r<br> TCP 1194       : http://ennt.nezavpn.my.id:81/TCP.ovpn\r<br> UDP 2200       : http://ennt.nezavpn.my.id:81/UDP.ovpn\r<br> SSL 442        : http://ennt.nezavpn.my.id:81/SSL.ovpn\r<br> ZIP FILE       : http://ennt.nezavpn.my.id:81/ALL.zip\r<br>=================================\r<br>~&gt; Payload WebSocket\r<br>\r<br>GET / HTTP/1.1[crlf]Host: ennt.nezavpn.my.id[crlf]Connection: Keep-Alive[crlf]Us\r<br>r-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]\r<br>=================================\r<br> Aktif Selama   : 30 Hari\r<br> Dibuat Pada    : 05 Sep, 2021\r<br> Berakhir Pada  : 05 Oct, 2021\r<br>=================================\r<br> ','SSH'),(2,'dhaay2709@gmail.com','06-09-2021','06-10-2021','  Penambahan user berhasil [username: Gagzvsv]\r<br><span style=\"color: green\">[Info]</span> ShadowsocksR Stopped Successfully !\r<br><span style=\"color: green\">[Info]</span> ShadowsocksR Start Successfully !\r<br>\r<br>\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\r<br>\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\r<br>\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\r<br>=================================\r<br> ~&gt; SHADOWSOCKSR SSR\r<br>=================================\r<br> ISP           : Google LLC\r<br> CITY          : Singapore\r<br> COUNTRY       : SG\r<br> Server IP     : 34.126.175.86\r<br> Host          : ennt.nezavpn.my.id\r<br> Port          : 1455\r<br> Password      : Gagzvsv\r<br> Encryption    : aes-256-cfb\r<br> Protocol      : origin\r<br> Obfs          : tls1.2_ticket_auth_compatible\r<br> Device limit  : 2\r<br>=================================\r<br>~&gt; LINK  SSR\r<br>\r<br>ssr://MzQuMTI2LjE3NS44NjoxNDU1Om9yaWdpbjphZXMtMjU2LWNmYjp0bHMxLjJfdGlja2V0X2F1dG\r<br>6UjJGbmVuWnpkZy9vYmZzcGFyYW09\r<br>=================================\r<br> Aktif Selama   : 30 Hari\r<br> Dibuat Pada    : 06 Sep, 2021\r<br> Berakhir Pada  : 06 Oct, 2021\r<br>=================================\r<br> ','SSR'),(3,'dhaay2709@gmail.com','06-09-2021','06-10-2021','\r<br>yahahaah\r<br>30\r<br>  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current\r<br>                                 Dload  Upload   Total   Spent    Left  Speed\r<br>100   929  100   929    0     0  51611      0 --:--:-- --:--:-- --:--:-- 51611\r<br>Memeriksa Hak Akses VPS...\r<br>\r<br>\r<br>Akses Diizinkan...\r<br>\r<br>\r<br>Username :yahahaah\r<br>Expired (hari):  Penambahan user berhasil [username: yahahaah]\r<br>[Info] ShadowsocksR Stopped Successfully !\r<br>[Info] ShadowsocksR Start Successfully !\r<br>\r<br>\r<br>\r<br>\r<br>=================================\r<br> ~&gt; SHADOWSOCKSR SSR\r<br>=================================\r<br> ISP           : Google LLC\r<br> CITY          : Singapore\r<br> COUNTRY       : SG\r<br> Server IP     : 34.126.175.86\r<br> Host          : ennt.nezavpn.my.id\r<br> Port          : 1456\r<br> Password      : yahahaah\r<br> Encryption    : aes-256-cfb\r<br> Protocol      : origin\r<br> Obfs          : tls1.2_ticket_auth_compatible\r<br> Device limit  : 2\r<br>=================================\r<br>~&gt; LINK  SSR\r<br>\r<br>ssr://MzQuMTI2LjE3NS44NjoxNDU2Om9yaWdpbjphZXMtMjU2LWNmYjp0bHMxLjJfdGlja2V0X2F1dG\r<br>6ZVdGb1lXaGhZV2cvb2Jmc3BhcmFtPQ==\r<br>=================================\r<br> Aktif Selama   : 30 Hari\r<br> Dibuat Pada    : 06 Sep, 2021\r<br> Berakhir Pada  : 06 Oct, 2021\r<br>=================================\r<br> - Mod By Dhansss X NezaVPN\r<br>\r<br>root@kangweb:~#','SSR'),(13,'bagussuhaemin203@gmail.com','09-09-2021','09-10-2021','30\r<br>Expired (hari) : \r<br>\r<br>\r<br>\r<br>=================================\r<br> ~&gt; TROJAN VPN\r<br>=================================\r<br> ISP                : Google LLC\r<br> CITY               : Singapore\r<br> COUNTRY            : SG\r<br> Remarks            : Aby\r<br> Host               : cahi.nezavpn.my.id\r<br> Port Trojan-GFW    : 2087\r<br> Port Trojan-GO     : 2053\r<br> Key Trojan-GFW     : Trojan-GFW_Aby\r<br> Key Trojan-GO      : Trojan-GO_Aby\r<br> Password Igniter   : Trojan-GO_Aby\r<br> Path WebSocket     : /DhanZaa\r<br>=================================\r<br> Trojan-GFW  : trojan://Trojan-GFW_Aby@cahi.nezavpn.my.id:2087/?sni=bug-anda.com\r<br>Aby\r<br>=================================\r<br> Trojan-GO   : trojan-go://Trojan-GO_Aby@cahi.nezavpn.my.id:2053/?sni=cahi.nezav\r<br>n.my.id&amp;type=ws&amp;host=cahi.nezavpn.my.id&amp;path=/DhanZaa&amp;encryption=none#Aby\r<br>=================================\r<br> Igniter-GO  : http://cahi.nezavpn.my.id:81/Aby-IgniterGO.json\r<br>=================================\r<br> Aktif Selama   : 30 Hari\r<br> Dibuat Pada    : 09 Sep, 2021\r<br> Berakhir Pada  : 09 Oct, 2021\r<br>=================================\r<br> - Mod By Dhansss X NezaVPN\r<br>\r<br>root@nezasingapore:~#','TROJAN'),(20,'bagussuhaemin203@gmail.com','10-09-2021','10-10-2021','Expired (hari): 30\r<br>Created symlink /etc/systemd/system/multi-user.target.wants/shadowsocks-libev-ser\r<br>ver@Coro-tls.service  /lib/systemd/system/shadowsocks-libev-server@.service.\r<br>Created symlink /etc/systemd/system/multi-user.target.wants/shadowsocks-libev-ser\r<br>ver@Coro-http.service  /lib/systemd/system/shadowsocks-libev-server@.service.\r<br>\r<br>\r<br>\r<br>\r<br>===================================\r<br> ~&gt; SHADOWSOCKS OBFS\r<br>===================================\r<br> ISP            : Google Asia Pacific Pte. Ltd.\r<br> CITY           : Jakarta\r<br> COUNTRY        : ID\r<br> Server IP      : 34.101.183.39\r<br> Server Host    : id-1.nezavpn.my.id\r<br> OBFS TLS       : 2445\r<br> OBFS HTTP      : 3445\r<br> Password       : Coro\r<br> Method         : aes-256-cfb\r<br>===================================\r<br>~&gt; OBFS  TLS\r<br>\r<br>ss://YWVzLTI1Ni1jZmI6Q29yb0BpZC0xLm5lemF2cG4ubXkuaWQ6MjQ0NQ==?plugin=obfs-local;\r<br>bfs=tls;obfs-host=bug-anda.com\r<br>===================================\r<br>~&gt; OBFS HTTP\r<br>\r<br>ss://YWVzLTI1Ni1jZmI6Q29yb0BpZC0xLm5lemF2cG4ubXkuaWQ6MzQ0NQ==?plugin=obfs-local;\r<br>bfs=http;obfs-host=bug-anda.com\r<br>===================================\r<br> Aktif Selama   : 30 Hari\r<br> Dibuat Pada    : 10 Sep, 2021\r<br> Berakhir Pada  : 10 Oct, 2021\r<br>=================================\r<br> - Mod By Dhansss X NezaVPN\r<br>\r<br>root@nezaindonesia:~#','Shadowsocks');
/*!40000 ALTER TABLE `tunneling` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `max_acc` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`, `username`, `email`, `password`, `max_acc`) VALUES (9,'dhaay','dhaay2709@gmail.com','Dhaay2709','997'),(10,'afdhan','afdhan134@gmail.com','afdhan@123','999982'),(11,'neza','mbahbolong313@gmail.com','Neza@123','0'),(12,'bagus suhaemin','bagussuhaemin203@gmail.com','Bagus1011','6'),(13,'ferdy','muhh65@gmail.com','ferdiansah00','0'),(33,'nama','afdhan46@gmail.com','wibu123','0'),(20,'faiz','faizfariz027@gmail.com','Neza@123','0'),(22,'wibika','foyarat670@shensufu.com','nezaku','0');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'nezavpn_panel'
--

--
-- Dumping routines for database 'nezavpn_panel'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-10  8:07:42
