<?php
  session_start();
  ob_flush();
  include "../con.php";
  $id = "13"; // Id Sesuai  Database
 ?>


<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Free SSH Premium">
    <meta name="author" content="DhansProject">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">

    <title>Free Premium VPN DhanZaa Project | OVPN Server</title>


   <link href="https://afdhan.github.io/sce/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

 <link rel="icon" href="https://raw.githubusercontent.com/Afdhan/spinner/main/999.png" height="330px" width="350px" type="image/jpg">

    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/fontawesome.css">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/begrond.css">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/owl.css">
  </head>
  <body>
 
<?php 
  
  $query = "select * from server where id=$id";
  $hasil = mysqli_query($db, $query);
  $data = mysqli_fetch_assoc($hasil);
  $name = $data["nama"];
  $ip = $data["ip"];
  $pw = $data["password"];
  $user = $data["username"];
  $limit = $data["sisa"];
  $domain = $data["domain"];
  $batas = '';
  if($limit == 0){
  	$batas = '<font color="red">Penuh</font>';
  }else {
  	$batas = '<font color="#00ff00">Tersedia</font>';
  }

echo '	<!-- Header -->
    <header class="" style="background: url(https://dhans-project.xyz/7777.jpg);background-size: cover;">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.html"><h2>Dhans X NezaVPN<!-- <em>TEAM</em>--></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
           <span class="navbar-toggler-icon" style="color:white"></span> 
          </button>
          <div class="collapse navbar-collapse" style="background: url(https://dhans-project.xyz/7777.jpg);background-size: cover;" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
             <li class="nav-item">
                <a class="nav-link" href="../"><font  color="white"><strong>Halaman Utama</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/ssh"><font  color="white"><strong>SSH Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/ovpn"><font  color="white"><strong>OpenVPN Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/v2ray"><font  color="white"><strong>V2Ray Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/trojan"><font  color="white"><strong>Trojan Server</font></strong></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
        <footer>
             <center>
  
     <!--IKLAN -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2835349828259042"
     crossorigin="anonymous"></script>         	
    
  
                 <form method="post">
           <div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
      <div class="dev"></div> 

              <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Server</font></th>
<td><font color="white">'.$name.'</font></td>
</tr>
<tr>
<th><font color="white">Host</font></th>
<td><font color="white">'.$domain.'</font></td>
</tr>
<tr>
<th><font color="white">TCP</font></th>
<td><font color="white">1194</font></td> 
</tr> 
<tr>
<th><font color="white">UDP</font></th>
<td><font color="white">2200</font></td> 
</tr>
<tr>
<th><font color="white">SSL</font></th>
<td><font color="white">442</font></td> 
</tr> 
<tr>
<th><font color="white">WebSocket</font></th>
<td><font color="white">2082</font></td> 
</tr> 
<tr>
<th><font color="white">BadVPN</font></th>
<td><font color="white">7100-7300</font></td> 
</tr>
<tr>
<th><font color="white">Aktif</font></th>
<td><font color="white">3 Hari</font></td> 
</tr>
  <tr>
<th><font color="white">Status</font></th>
<td>'.$batas.'</td> 
</tr>
<tr>
<th><font color="white">Limit</font></th>
<td><font color="white">'.$limit.'</font></td> 
</tr>
</tbody>
</table>
<div class="dev"></div> 

<input type="text" name="username" class="form-control" placeholder="Username" aotofocus></input>
<br>
	<input type="password" name="password" class="form-control" placeholder="Password"></input>
<div class="dev"></div> 
              <input type="submit" name="submit" class="btn btn-primary"> </form>
            </div>
          </div></form>';
          
 
 $username = mysqli_real_escape_string($db, $_POST["username"]);
 $pass = mysqli_real_escape_string($db, $_POST["password"]);

   if(empty($_POST["submit"])){
        
  }elseif($limit == 0){
  	echo '<div class="col-md-12">
          <div class="sub-footer"></div></div><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item"><font color="white">Server Sudah Penuh! Silahkan Pilih Server Lain.</font></div></div>';
  }elseif(empty($username)){
        echo '<div class="col-md-12">
          <div class="sub-footer"></div></div><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item"><font color="white">Username Tidak Boleh Kosong!</font></div></div>';
  }elseif(empty($pass)){
    echo '<div class="col-md-12">
          <div class="sub-footer"></div></div><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item"><font color="white">Password Tidak Boleh Kosong!</font></div></div>';
  }else{
  set_include_path(get_include_path() . PATH_SEPARATOR . '../phpseclib');
  include "File/ANSI.php";
  include('Net/SSH2.php');
  

  $host= $ip;
  $root_password= $pw; 
  $ssh = new Net_SSH2($host);
  if (!$ssh->login($user, $root_password)) {
    die('<div class="col-md-12"><div class="sub-footer"></div></div><div class="col-md-4 col-sm-6 col-xs-12"><div class="pricing-item"><font color="red">ERROR! VPS BERMASALAH</font></div></div>');
    }
    
  $ansi = new File_ANSI(); 
  $ssh->write("sudo su\n");
  $ssh->write("usernew\n");
  $ssh->read();
  $ssh->write("$username\n");
  $ssh->write("$pass\n");
  $ssh->write("3\n");
  $ansi->appendString($ssh->read("")); 
  $anu = $ansi->getHistory();
   
   
    if(preg_match("/already/", $anu)){
   echo '<div class="col-md-12">
          <div class="sub-footer"></div></div><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item"><font color="white">Username Sudah Digunakan!</font></div></div>';
  }elseif(preg_match("/- Mod By Dhansss X NezaVPN/", $anu)){
 $ac = $limit - 1;
   
    $query2 = "UPDATE server SET sisa=$ac WHERE id=$id";
    mysqli_query($db, $query2);
 
    $sebulan= mktime(0,0,0,date("n"),date("j")+3,date("Y")); 
    $exp = date("d-m-Y", $sebulan); 
echo '<div class="col-md-12">
          <div class="sub-footer"></div></div>
    <center><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
             	<h4> Akun Berhasil Dibuat!</h4>
  <div class="dev"></div>
<table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Hostname</font></th>
<td><font color="white">'.$domain.'</font></td>
</tr>
<tr>
<th><font color="white">Username</font></th>
<td><font color="white">'.$username.'</font></td>
</tr>
<tr>
<th><font color="white">Password</font></th>
<td><font color="white">'.$pass.'</font></td>
</tr>
<tr>
<th><font color="white">Expired</font></th>
<td><font color="white">'.$exp.'</font></td> 
</tr>
</tbody>
</table>
<div class="dev"></div>
<p><a href="http://'.$domain.':81/TCP.ovpn" class="btn btn-primary">OpenVPN TCP</a></p><br>
<p><a href="http://'.$domain.':81/UDP.ovpn" class="btn btn-primary">OpenVPN UDP</a></p><br>
<p><a href="http://'.$domain.':81/SSL.ovpn" class="btn btn-primary">OpenVPN SSL</a></p><br>
<p><a href="http://'.$domain.':81/ALL.zip" class="btn btn-primary">ALL OpenVPN</a></p>
<div class="dev"></div>
<textarea cols="20" rows="3" id="non" readonly>GET / HTTP/1.1[crlf]Host: '.$domain.'[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]</textarea><br>
<center><p><button type="button" class="btn btn-primary" onclick="copy_non()">COPY</button></p></center>
</div></div></center>';

   }else{
        echo '<div class="col-md-12">
          <div class="sub-footer"></div></div><center><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item"><font color="white">Create Gagal! Server Bermasalah</font></div></div></center>';
   }
}     
?>
  
  <center>          
            <!--IKLAN -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2835349828259042"
     crossorigin="anonymous"></script>         	
   </center>
   
          <div class="col-md-12">
          <div class="sub-footer">
              <p>Copyright 2021 | <a rel="nofollow" href="https://resselervpnku.tech">DhanZaa Team</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    

    <script src="https://afdhan.github.io/sce/vendor/jquery/jquery.min.js"></script>
    <script src="https://afdhan.github.io/sce/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="https://afdhan.github.io/sce/assets/js/custom.js"></script>
    <script src="https://afdhan.github.io/sce/assets/js/owl.js"></script>
    <script src="https://afdhan.github.io/sce/assets/js/accordions.js"></script>

<script type="text/javascript">
function copy_non() {
        document.getElementById("non").select();
        document.execCommand("copy");
        alert("Payload Berhasil Dicopy Ke Clipboard!");
    }
    </script>
    <script language = "text/Javascript"> 
    
      cleared[0] = cleared[1] = cleared[2] = 0; 
      function clearField(t){ 
      if(! cleared[t.id]){ 
          cleared[t.id] = 1;  
          t.value=''; 
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>
