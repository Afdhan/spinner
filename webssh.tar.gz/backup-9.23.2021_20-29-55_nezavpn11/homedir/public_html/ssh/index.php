<?php
  session_start();
  ob_flush();
  include "../con.php";
  ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Free SSH Premium">
    <meta name="author" content="DhansProject">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">
<!-- URL Theme Color untuk Chrome, Firefox OS, Opera dan Vivaldi -->
<meta name="theme-color" content="#001b2a" />
<!-- URL Theme Color untuk Windows Phone -->
<meta name="msapplication-navbutton-color" content="#001b2a" />
<!-- URL Theme Color untuk iOS Safari -->
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="#001b2a" />
    <title>Free Premium VPN DhanZaa Project</title>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
 
    <link href="https://afdhan.github.io/sce/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 <link rel="icon" href="https://raw.githubusercontent.com/Afdhan/spinner/main/999.png" height="330px" width="350px" type="image/jpg">

    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/fontawesome.css">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/begrond.css">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/owl.css">
     <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4064134056656469"
     crossorigin="anonymous"></script>
	  
</head>
  
  <body>
  	<!-- Header -->
    <header class="" style="background: url(https://dhans-project.xyz/7777.jpg);background-size: cover;">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="../"><h2>Dhans X NezaVPN<!-- <em>TEAM</em>--></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
           <span class="navbar-toggler-icon" style="color:white"></span> 
          </button>
          <div class="collapse navbar-collapse" style="background: url(https://dhans-project.xyz/7777.jpg);background-size: cover;" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
             <li class="nav-item">
                <a class="nav-link" href="../"><font  color="white"><strong>Halaman Utama</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/ssh"><font  color="white"><strong>SSH Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/ovpn"><font  color="white"><strong>OpenVPN Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/v2ray"><font  color="white"><strong>V2Ray Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/trojan"><font  color="white"><strong>Trojan Server</font></strong></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>	
  <footer>
       <center>
             <section class="banner_main">
         <div class="container">
            <!--
            	<div class="col-md-7">
           -->       <div class="text-img">
                     <figure><img src="https://dhans-project.xyz/img2.png" /></figure>
                  </div>
               </div> <!--
              <div class="col-md-5">
              -->    <div class="text-bg">
        <!--            <h1>Dhanss  X NezaVPN</h1>  -->
                     <span>Gratis SSH / VPN Premium</span>
             <!--        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>
             -->        <br><a href="../">Home</a>
                  </div>
               </div>
               
            </div>
         </div>
      </section>
       
                     
        <!--IKLAN -->
<script async="async" data-cfasync="false" src="//stammerail.com/6177d0e0e0bc21625f8f23a876f9c067/invoke.js"></script>
<div id="container-6177d0e0e0bc21625f8f23a876f9c067"></div>
     <audio autoplay>
    <source src="https://dhans-project.xyz/memek5.MP3" type="audio/mpeg">
</audio>
  
       	<div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
           <center><h6 style="font-family: serif;font-size: 20px; color: white; background: url(https://dhans-project.xyz/7777.jpg); width: 150px; border: 0.1px solid white; border-radius: 3px">SSH SERVER</h6>
             </center>
          <div class="dev"></div> <div class="table-responsive-lg">
    <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Tipe</th>
<th><font color="white">SSH</th>
</tr>
<tr>
<th><font color="white">ISP</th>
<th><font color="white">Azure</th>
</tr>
<tr>
<th><font color="white">Country</th>
<th><font color="white">Singapore</th>
</tr>
<tr>
<th><font color="white">Region</th>
<th><font color="white">SG</th>
</tr>
</tbody>
</table></div>

<div class="dev"></div>
              <a href="ssh-azure" class="main-button">BUAT</a>
            </div>
          </div>
          </div>
          </div>
                    
            <!--IKLAN -->
<script data-cfasync='false' type='text/javascript' src='//p438449.clksite.com/adServe/banners?tid=438449_858851_4'></script>
   
          </center>
          
          <div class="col-md-12">
          <div class="sub-footer">
          	</div>
          </div>      
       	       <center>
       	<div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
           <center><h6 style="font-family: serif;font-size: 20px; color: white; background: url(https://dhans-project.xyz/7777.jpg); width: 150px; border: 0.1px solid white; border-radius: 3px">SSH SERVER</h6>
             </center>
          <div class="dev"></div> <div class="table-responsive-lg">
    <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Tipe</th>
<th><font color="white">SSH</th>
</tr>
<tr>
<th><font color="white">ISP</th>
<th><font color="white">AWS Amazon</th>
</tr>
<tr>
<th><font color="white">Country</th>
<th><font color="white">Singapore</th>
</tr>
<tr>
<th><font color="white">Region</th>
<th><font color="white">SG</th>
</tr>
</tbody>
</table></div>

<div class="dev"></div>
              <a href="ssh-aws" class="main-button">BUAT</a>
            </div>
          </div>
          </div>
          </div>
                    
            <!--IKLAN -->
<script data-cfasync='false' type='text/javascript' src='//p438449.clksite.com/adServe/banners?tid=438449_858851_4'></script>
   
          </center>
          
          <div class="col-md-12">
          <div class="sub-footer">
          	</div>
          </div>
          
 <center>
       	<div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
           <center><h6 style="font-family: serif;font-size: 20px; color: white; background: url(https://dhans-project.xyz/7777.jpg); width: 150px; border: 0.1px solid white; border-radius: 3px">SSH SERVER</h6>
             </center>
          <div class="dev"></div> <div class="table-responsive-lg">
    <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Tipe</th>
<th><font color="white">SSH</th>
</tr>
<tr>
<th><font color="white">ISP</th>
<th><font color="white">Linode</th>
</tr>
<tr>
<th><font color="white">Country</th>
<th><font color="white">Singapore</th>
</tr>
<tr>
<th><font color="white">Region</th>
<th><font color="white">SG</th>
</tr>
</tbody>
</table></div>

<div class="dev"></div>
              <a href="ssh-linode" class="main-button">BUAT</a>
            </div>
          </div>
          </div>
          </div>
               </center>
 <div class="services-section">
      <div class="container">
        <div class="row">
        <div class="col-md-12">
            <div class="section-heading">
   <!--           <span>Hosting Services</span>   -->
              <font color="white" size="5px" border="blue">Mengapa Menggunakan SSH Tunneling? </font>  
              <p style="font-family:serif;font-style:italic">Dengan menggunakan SSH Tunneling, memungkinkan kita untuk mem-forward sebuah port dari remote server ke local atau sebaliknya, dapat juga berfungsi sebagai Proxy server.</p>
            </div>
          </div> 
     
     <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="service-item">
              <i class="fa fa-dashboard"></i>
              <h4><strong>Transfer Data Cepat</strong></h4>
              <div class="gg"></div>
              
              <p style="font-family:cursive">Kami menggunakan server premium berkecepatan tinggi</p>
              </div></div>
 <!-- <div style="background-color: red; width:100%; height:3px; margin:35px 0px 35px 0px; border-radius:5px"> </div>  -->
       <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="service-item">
    <i class="fa fa-group"></i>
              <h4><strong>Lewati Privasi Internet</strong></h4>
              <div class="gg"></div>
              <p style="font-family:cursive">ISP anda tidak akan terdeteksi</p>
              </div></div>
       <!--       <div style="background-color: red; width:100%; height:3px; margin:35px 0px 35px 0px; border-radius:5px"> </div>   -->
            <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="service-item">
  <i class="fa fa-chain-broken"></i>
              <h4><strong>Sembunyikan IP Asli</strong></h4>
              <div class="gg"></div>
              <p style="font-family:cursive">Jelajahi dengan alamat IP Pribadi dan Aman</p>
            </div>
          </div>
        </div>
      </div>
    </div>         
            <!--IKLAN -->
<script data-cfasync='false' type='text/javascript' src='//p438449.clksite.com/adServe/banners?tid=438449_858851_4'></script>
   
          </center>
       
       <div class="col-md-12">
          <div class="sub-footer">
              <p>Copyright 2021 | <a rel="nofollow" href="https://resselervpnku.tech">DhanZaa Team</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- IKLAN -->
    <script data-cfasync='false' type='text/javascript' src='//p438449.clksite.com/adServe/banners?tid=438449_858851_4'></script>

    <script src="https://afdhan.github.io/sce/vendor/jquery/jquery.min.js"></script>
    <script src="https://afdhan.github.io/sce/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="https://afdhan.github.io/sce/assets/js/custom.js"></script>
    <script src="https://afdhan.github.io/sce/assets/js/owl.js"></script>
    <script src="https://afdhan.github.io/sce/assets/js/accordions.js"></script>

<script type="text/javascript">
function copy_non() {
        document.getElementById("non").select();
        document.execCommand("copy");
        alert("Payload Berhasil Dicopy Ke Clipboard!");
    }
    </script>
    <script language = "text/Javascript"> 
    
      cleared[0] = cleared[1] = cleared[2] = 0; 
      function clearField(t){ 
      if(! cleared[t.id]){ 
          cleared[t.id] = 1;  
          t.value=''; 
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>
