<?php
  session_start();
  ob_flush();
  include "../con.php";
  $id = "14"; // Id Sesuai  Database
 ?>


<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Free SSH Premium">
    <meta name="author" content="DhansProject">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">
<!-- URL Theme Color untuk Chrome, Firefox OS, Opera dan Vivaldi -->
<meta name="theme-color" content="#001b2a" />
<!-- URL Theme Color untuk Windows Phone -->
<meta name="msapplication-navbutton-color" content="#001b2a" />
<!-- URL Theme Color untuk iOS Safari -->
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="#001b2a" />
    <title>Free Premium VPN DhanZaa Project | SSH Server</title>


   <link href="https://afdhan.github.io/sce/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

 <link rel="icon" href="https://raw.githubusercontent.com/Afdhan/spinner/main/999.png" height="330px" width="350px" type="image/jpg">

    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/fontawesome.css">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/begrond.css">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/owl.css">
     <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4064134056656469"
     crossorigin="anonymous"></script>
  </head>
  <body>
<?php 
  
  $query = "select * from server where id=$id";
  $hasil = mysqli_query($db, $query);
  $data = mysqli_fetch_assoc($hasil);
  $name = $data["nama"];
  $ip = $data["ip"];
  $pw = $data["password"];
  $user = $data["username"];
  $limit = $data["sisa"];
  $domain = $data["domain"];
  $batas = '';
  if($limit == 0){
  	$batas = '<font color="red">Penuh</font>';
  }else {
  	$batas = '<font color="#00ff00">Tersedia</font>';
  }

echo '
        	<!-- Header -->
    <header class="" style="background: url(https://dhans-project.xyz/7777.jpg);background-size: cover;">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="../"><h2>Dhans X NezaVPN<!-- <em>TEAM</em>--></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
           <span class="navbar-toggler-icon" style="color:white"></span> 
          </button>
          <div class="collapse navbar-collapse" style="background: url(https://dhans-project.xyz/7777.jpg);background-size: cover;" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
             <li class="nav-item">
                <a class="nav-link" href="../"><font  color="white"><strong>Halaman Utama</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/ssh"><font  color="white"><strong>SSH Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/ovpn"><font  color="white"><strong>OpenVPN Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/v2ray"><font  color="white"><strong>V2Ray Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/trojan"><font  color="white"><strong>Trojan Server</font></strong></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
  <footer>
  <center>
   <section class="banner_main">
         <div class="container">
            <!--
            	<div class="col-md-7">
           -->       <div class="text-img">
                     <figure><img src="https://dhans-project.xyz/img2.png" /></figure>
                  </div>
               </div> <!--
              <div class="col-md-5">
              -->    <div class="text-bg">
        <!--            <h1>Dhanss  X NezaVPN</h1>  -->
                     <span>Gratis SSH / VPN Premium</span>
             <!--        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>
                     <br><a href="#buat">Buat</a>
                -->  </div>
               </div>
               
            </div>
         </div>
      </section>
        <!--IKLAN -->
<script async="async" data-cfasync="false" src="//stammerail.com/6177d0e0e0bc21625f8f23a876f9c067/invoke.js"></script>
<div id="container-6177d0e0e0bc21625f8f23a876f9c067"></div>
     <audio autoplay>
    <source src="https://dhans-project.xyz/memek5.MP3" type="audio/mpeg">
</audio>
    
  
                 <form method="post">
           <div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
      <div class="dev"></div> 
<div class="table-responsive-lg">
              <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Server</font></th>
<td><font color="white">'.$name.'</font></td>
</tr>
<tr>
<th><font color="white">Host</font></th>
<td><font color="white">'.$domain.'</font></td>
</tr>
<tr>
<th><font color="white">OpenSSH</font></th>
<td><font color="white">22</font></td> 
</tr>
<tr>
<th><font color="white">Dropbear</font></th>
<td><font color="white">143, 109</font></td> 
</tr> 
<tr>
<th><font color="white">SSL/TLS</font></th>
<td><font color="white">567, 171</font></td>
</tr>
<tr>
<th><font color="white">Squid Port</font></th>
<td><font color="white">3128, 8080</font></td> 
</tr>
<tr>
<th><font color="white">WS TLS</font></th>
<td><font color="white">443</font></td>
</tr>
<tr>
<th><font color="white">WS Dropbear</font></th>
<td><font color="white">8880</font></td> 
</tr>
<tr>
<th><font color="white">WS OpenSSH</font></th>
<td><font color="white">2095</font></td>
</tr>
<tr>
<th><font color="white">BadVPN</font></th>
<td><font color="white">7100-7300</font></td> 
</tr>
<tr>
<th><font color="white">Aktif</font></th>
<td><font color="white">3 Hari</font></td> 
</tr>
  <tr>
<th><font color="white">Status</font></th>
<td>'.$batas.'</td> 
</tr>
<tr>
<th><font color="white">Limit</font></th>
<td><font color="white">'.$limit.'</font></td> 
</tr>
</tbody>
</table></div>
<div class="dev"></div> 

<input type="text" name="username" class="form-control" placeholder="Username" autofocus></input>
<br>
	<input type="password" name="password" class="form-control" placeholder="Password"></input>
<div class="dev"></div> 
              <input type="submit" name="submit" class="btn btn-primary"> </form>
            </div>
          </div></form>  
          
          <script type="text/javascript" src="//p438449.clksite.com/adServe/banners?tid=438449_858851_5&type=floating_banner&size=6&side=center&position=bottom"></script>
          
          <script type="text/javascript" src="//stammerail.com/41/3b/e8/413be8cfb539990db6aa2bd09bde2bb6.js"></script>';
          
 
 $username = mysqli_real_escape_string($db, $_POST["username"]);
 $pass = mysqli_real_escape_string($db, $_POST["password"]);

   if(empty($_POST["submit"])){
        
  }elseif($limit == 0){
  	echo '<div class="col-md-12">
          <div class="sub-footer"></div></div><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item"><font color="white">Server Sudah Penuh! Silahkan Pilih Server Lain.</font></div></div>';
  }elseif(empty($username)){
        echo '<div class="col-md-12">
          <div class="sub-footer"></div></div><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item"><font color="white">Username Tidak Boleh Kosong!</font></div></div>';
  }elseif(empty($pass)){
    echo '<div class="col-md-12">
          <div class="sub-footer"></div></div><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item"><font color="white">Password Tidak Boleh Kosong!</font></div></div>';
  }else{
  set_include_path(get_include_path() . PATH_SEPARATOR . '../phpseclib');
  include "File/ANSI.php";
  include('Net/SSH2.php');
  

  $host= $ip;
  $root_password= $pw; 
  $ssh = new Net_SSH2($host);
  if (!$ssh->login($user, $root_password)) {
    die('<div class="col-md-12"><div class="sub-footer"></div></div><div class="col-md-4 col-sm-6 col-xs-12"><div class="pricing-item"><font color="red">ERROR! VPS BERMASALAH</font></div></div>');
    }
    
  $ansi = new File_ANSI(); 
  $ssh->write("sudo su\n");
  $ssh->write("usernew\n");
  $ssh->read();
  $ssh->write("$username\n");
  $ssh->write("$pass\n");
  $ssh->write("3\n");
  $ansi->appendString($ssh->read("")); 
  $anu = $ansi->getHistory();
   
   
    if(preg_match("/already/", $anu)){
   echo '<div class="col-md-12">
          <div class="sub-footer"></div></div><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item"><font color="white">Username Sudah Digunakan!</font></div></div>';
  }elseif(preg_match("/- Mod By Dhansss X NezaVPN/", $anu)){
 $ac = $limit - 1;
   
    $query2 = "UPDATE server SET sisa=$ac WHERE id=$id";
    mysqli_query($db, $query2);
 
    $sebulan= mktime(0,0,0,date("n"),date("j")+3,date("Y")); 
    $exp = date("d-m-Y", $sebulan); 
echo '<div class="col-md-12">
          <div class="sub-footer"></div></div>
    <center><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
             	<h4> Akun Berhasil Dibuat!</h4>
  <div class="dev"></div><div class="table-responsive-lg">
<table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Hostname</font></th>
<td><font color="white">'.$domain.'</font></td>
</tr>
<tr>
<th><font color="white">Username</font></th>
<td><font color="white">'.$username.'</font></td>
</tr>
<tr>
<th><font color="white">Password</font></th>
<td><font color="white">'.$pass.'</font></td>
</tr>
<tr>
<th><font color="white">Expired</font></th>
<td><font color="white">'.$exp.'</font></td> 
</tr>
</tbody>
</table></div>
<textarea cols="20" rows="3" id="non" readonly>GET / HTTP/1.1[crlf]Host: '.$domain.'[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]</textarea><br>
<center><p><button type="button" class="btn btn-primary" onclick="copy_non()">COPY</button></p></center>
</div></div></center>';

   }else{
        echo '<div class="col-md-12">
          <div class="sub-footer"></div></div><center><div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item"><font color="white">Create Gagal! Server Bermasalah</font></div></div></center>';
   }
}     
?>
  
  </center>
 <div class="services-section">
      <div class="container">
        <div class="row">
        <div class="col-md-12">
            <div class="section-heading">
   <!--           <span>Hosting Services</span>   -->
              <font color="white" size="5px" border="blue">Mengapa Menggunakan SSH Tunneling? </font>  
              <p style="font-family:serif;font-style:italic">Dengan menggunakan SSH Tunneling, memungkinkan kita untuk mem-forward sebuah port dari remote server ke local atau sebaliknya, dapat juga berfungsi sebagai Proxy server.</p>
            </div>
          </div> 
     
     <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="service-item">
              <i class="fa fa-dashboard"></i>
              <h4><strong>Transfer Data Cepat</strong></h4>
              <div class="gg"></div>
              
              <p style="font-family:cursive">Kami menggunakan server premium berkecepatan tinggi</p>
              </div></div>
 <!-- <div style="background-color: red; width:100%; height:3px; margin:35px 0px 35px 0px; border-radius:5px"> </div>  -->
       <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="service-item">
    <i class="fa fa-group"></i>
              <h4><strong>Lewati Privasi Internet</strong></h4>
              <div class="gg"></div>
              <p style="font-family:cursive">ISP anda tidak akan terdeteksi</p>
              </div></div>
       <!--       <div style="background-color: red; width:100%; height:3px; margin:35px 0px 35px 0px; border-radius:5px"> </div>   -->
            <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="service-item">
  <i class="fa fa-chain-broken"></i>
              <h4><strong>Sembunyikan IP Asli</strong></h4>
              <div class="gg"></div>
              <p style="font-family:cursive">Jelajahi dengan alamat IP Pribadi dan Aman</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Services Ends Here -->
  <center>                  
            <!--IKLAN -->
<script data-cfasync='false' type='text/javascript' src='//p438449.clksite.com/adServe/banners?tid=438449_858851_4'></script>
   </center>
   
          <div class="col-md-12">
          <div class="sub-footer">
              <p>Copyright 2021 | <a rel="nofollow" href="https://resselervpnku.tech">DhanZaa Team</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    
<script data-cfasync='false' type='text/javascript' src='//p438449.clksite.com/adServe/banners?tid=438449_858851_4'></script>
    <script src="https://afdhan.github.io/sce/vendor/jquery/jquery.min.js"></script>
    <script src="https://afdhan.github.io/sce/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="https://afdhan.github.io/sce/assets/js/custom.js"></script>
    <script src="https://afdhan.github.io/sce/assets/js/owl.js"></script>
    <script src="https://afdhan.github.io/sce/assets/js/accordions.js"></script>

<script type="text/javascript">
function copy_non() {
        document.getElementById("non").select();
        document.execCommand("copy");
        alert("Payload Berhasil Dicopy Ke Clipboard!");
    }
    </script>
    <script language = "text/Javascript"> 
    
      cleared[0] = cleared[1] = cleared[2] = 0; 
      function clearField(t){ 
      if(! cleared[t.id]){ 
          cleared[t.id] = 1;  
          t.value=''; 
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>
