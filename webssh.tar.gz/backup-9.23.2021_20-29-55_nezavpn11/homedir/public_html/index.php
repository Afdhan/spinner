<?php
  session_start();
  ob_flush();
  include "con.php";
 
  ?>


<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Free SSH Premium">
    <meta name="author" content="DhansProject">
    <!-- URL Theme Color untuk Chrome, Firefox OS, Opera dan Vivaldi -->
<meta name="theme-color" content="#001b2a" />
<!-- URL Theme Color untuk Windows Phone -->
<meta name="msapplication-navbutton-color" content="#001b2a" />
<!-- URL Theme Color untuk iOS Safari -->
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="#001b2a" />
    <meta name="hilltopads-site-verification" content="bae4d06406281ee0552f2bb3e1348e9c25a5d273" />
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">

    <title>VPN PREMIUM BY DHANZAA PROJECT</title>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
 
    <link href="https://afdhan.github.io/sce/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 <link rel="icon" href="https://raw.githubusercontent.com/Afdhan/spinner/main/999.png" height="330px" width="350px" type="image/jpg">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/fontawesome.css">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/begrond.css">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/owl.css">
    <meta content="8801d3f359b04f655cf041114736648a" name="hitads" />
	<script type="text/javascript" src="//hitsmedia.us/ad_onclick.php?u=MjQ2NA=="></script>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4064134056656469"
     crossorigin="anonymous"></script>
</head>
  
  <body>
  
  	<style type="text/css">
  h1,h2,p,a{
		font-family: sans-serif;
		font-weight: normal;
	}
 
     .garis {
	width: 100%;
	height: 1px;
	background-color: white;
	margin: 20px 0px 20px 0px;;
    }
    .inijam {
        font-family: serif;
    	background: url(https://dhans-project.xyz/7777.jpg);
        font-size: 36px;
        color: white;
        border: 1px solid white;
        border-radius: 5px;
        }
	.jam_analog {
		background: url(https://dhans-project.xyz/7777.jpg);
		position: relative;
		width: 140px;
		height: 140px;
		border: 3px solid white;
		border-radius: 50%;
		padding: 10px;
		margin:10px auto;
	}
 
	.jamku {
		height: 100%;
		width: 100%;
		position: relative;
	}
 
	.jarum {
		position: absolute;
		width: 50%;
		background: silver;
		top: 50%;
		transform: rotate(90deg);
		transform-origin: 100%;
		transition: all 0.05s cubic-bezier(0.1, 2.7, 0.58, 1);
	}
 
	.lingkaran_tengah {
		width: 24px;
		height: 24px;
		background: transparent;
		border: 4px solid white;
		position: absolute;
		top: 50%;
		left: 50%;
		margin-left: -14px;
		margin-top: -14px;
		border-radius: 50%;
	}
 
	.jarum_detik {
		height: 2px;
		border-radius: 1px;
		background: red;
	}
 
	.jarum_menit {
		height: 4px;
		border-radius: 4px;
	}
 
	.jarum_jam {
		height: 6px;
		border-radius: 4px;
		width: 35%;
		left: 15%;
		}
		
		* {box-sizing: border-box}
     /* body {font-family: Verdana,sans-serif;}
*/
.mySlides {display:none}

.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}


.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

.dot {
  height: 13px;
  width: 13px;
  margin: 0 2px;
  background-color: transparent;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}


.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration:3s;
  animation-name: fade;
  animation-duration: 7s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@media only screen and (max-width: 300px) {
  .text {font-size: 11px
	}
	
.blink {
animation: blink-animation 1s steps(5, start) infinite;
-webkit-animation: blink-animation 1s steps(5, start) infinite;
    }
@keyframes blink-animation {
     to {
      visibility: hidden;
   }
 }
@-webkit-keyframes blink-animation {
       to {
       visibility: hidden;
      }
}
</style>
<!-- Header -->
    <header class="" style="background: url(https://dhans-project.xyz/7777.jpg);background-size: cover;">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="./"><h2>Dhans X NezaVPN<!-- <em>TEAM</em>--></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
           <span class="navbar-toggler-icon" style="color:white"></span> 
          </button>
          <div class="collapse navbar-collapse" style="background: url(https://dhans-project.xyz/7777.jpg);background-size: cover;" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
             <li class="nav-item">
                <a class="nav-link" href="./"><font  color="white"><strong>Halaman Utama</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="ssh"><font  color="white"><strong>SSH Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="ovpn"><font  color="white"><strong>OpenVPN Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="v2ray"><font  color="white"><strong>V2Ray Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="trojan"><font  color="white"><strong>Trojan Server</font></strong></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
<footer>
       	       <center>
       	    <section class="banner_main">
         <div class="container">
            <!--
            	<div class="col-md-7">
           -->       <div class="text-img">
                     <figure><img src="https://dhans-project.xyz/img2.png" /></figure>
                  </div>
               </div> <!--
              <div class="col-md-5">
              -->    <div class="text-bg">
        <!--            <h1>Dhanss  X NezaVPN</h1>  -->
                     <span>Gratis SSH / VPN Premium</span>
             <!--        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>
             -->        <br><a href="#buat">Buat</a>
                  </div>
               </div>
               
            </div>
         </div>
      </section>
     
     <script async="async" data-cfasync="false" src="//stammerail.com/6177d0e0e0bc21625f8f23a876f9c067/invoke.js"></script>
<div id="container-6177d0e0e0bc21625f8f23a876f9c067"></div>
         <br>
       	<marquee direction="left" style="margin-bottom:20px; margin-top:0px"><font color="white">!!! JANGAN SHARE AKUN KE PUBLIK JIKA TIDAK INGIN  DIBANNED !!!</font></marquee>
       	     
       		<marquee direction="right" style="margin-bottom:30px; margin-top:0px"><font color="white">!!! JANGAN SHARE AKUN KE PUBLIK JIKA TIDAK INGIN  DIBANNED !!!</font></marquee>
  
     <div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
                 <p style="font-family:monospace;font-size:20px;letter-spacing:5px;margin-bottom:5px;background: url(https://dhans-project.xyz/7777.jpg); width: 100%; border:2px"><strong>IP ANDA</strong> </p><p style="width:100%;height:1px;background:white;margin: 5px 0px 10px 0px"></p>
                 <h6 style="font-family:serif;font-size:25px;color:white; background: url(https://dhans-project.xyz/7777.jpg); width: 100%; border: 0.1px solid white; border-radius: 3px">
                 <?php echo $_SERVER['REMOTE_ADDR']; ?></h6>
                 <!--<div style="width:100%">-->
             	  <audio autoplay>
    <source src="https://dhans-project.xyz/memek5.MP3" type="audio/mpeg">
</audio>
             	</div></div>
       <div class="col-md-12">
          <div class="sub-footer">
          	</div>
          </div>
  
       <div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
             	<center>
             	<h6 style="font-family: serif;font-size: 25px; color: white; background: url(https://dhans-project.xyz/7777.jpg); width: 100%; border: 0.1px solid white; border-radius: 3px">WAKTU SERVER</h6>
       
        </center>
        <div class="garis"></div>
           <div class="jam_analog">
	<div class="jamku">
		<div class="jarum jarum_detik"></div>
		<div class="jarum jarum_menit"></div>
		<div class="jarum jarum_jam"></div> 
	</div>
</div>
<div class="garis"></div> 
    <h1 class="inijam" id="jam"></h1>
    <div class="garis"></div>
    <h6 style="font-family: serif;font-size: 20px; color: white; background: url(https://dhans-project.xyz/7777.jpg); width: 100%; border: 0.1px solid white; border-radius: 3px"><marquee direction="left"> Reset Server Pukul <font color="red">00:00:01</font> GMT+7</marquee></h6>
  	</div>
<!--  <div id="tgl"></div>  -->
             </div>
         
             </center>
             
        <script async="async" data-cfasync="false" src="//stammerail.com/6177d0e0e0bc21625f8f23a876f9c067/invoke.js"></script>
<div id="container-6177d0e0e0bc21625f8f23a876f9c067"></div>     
             <!-- Services Starts Here -->
    <div class="services-section">
      <div class="container">
        <div class="row">
  <!--        <div class="col-md-12">
            <div class="section-heading">
              <span>Hosting Services</span>
              <h2>Services we provide</h2>
              <p>Host Cloud is a professional Bootstrap 4 template by TemplateMo for your hosting company websites. There are 4 HTML pages included in this template. You can feel free to customize anything. Please share this template to your friends. Thank you.</p>
            </div>
          </div> -->
          <div class="col-md-4 col-sm-6 col-xs-12">
            <div class="service-item">
              <i class="fa fa-server"></i>
              <h4><strong>Layanan Server Premium</strong></h4>
              <div class="gg"></div>
              <p style="font-family:cursive;font-size:17px">Kami menyediakan layanan server terbaik untuk Anda. Sehingga Anda akan merasakan pengalaman baru yang tidak akan Anda temukan di tempat lain.</p>
            </div>
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12">
            <div class="service-item">
              <i class="fa fa-rocket"></i>
              <h4><strong>Diberikan Secara Gratis</strong></h4>
              <div class="gg"></div>
              <p style="font-family:cursive;font-size:17px">Kami memberikan beberapa layanan server berkualitas tinggi dan gratis untuk Anda. Anda bebas memilih server tanpa harus keluar uang.</p>
            </div>
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12">
            <div class="service-item">
              <i class="fa fa-lock"></i>
              <h4><strong>Dijamin 100% Aman</strong></h4>
              <div class="gg"></div>
              <p style="font-family:cursive;font-size:17px">Kami tidak menggunakan log atau alat apa pun untuk memantau aktivitas Anda. Kami dapat memastikan keamanan data Anda tetap terjaga.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
   
             <div class="col-md-12">
          <div class="sub-footer">
          	</div>
          </div>
       <center>
 
       <div class="col-md-4 col-sm-6 col-xs-12" id="buat">
             <div class="pricing-item">
           <center><h6 style="font-family: serif;font-size: 20px; color: white; background: url(https://dhans-project.xyz/7777.jpg); width: 150px; border: 0.1px solid white; border-radius: 3px">SSH SERVER</h6>
             </center>
          <div class="dev"></div> 
    <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Tipe</th>
<th><font color="white">SSH</th>
</tr>
<tr>
<th><font color="white">Aktif</th>
<th><font color="white">3 Hari</th>
</tr>
<tr>
<th><font color="white">Tersedia</th>
<th><font color="white">3 Server</th>
</tr>
</tbody>
</table>

<div class="dev"></div>
              <a href="ssh" class="main-button">PILIH</a>
            </div>
          </div>
          </div>
          </div>
          </center>
          
                <div class="col-md-12">
          <div class="sub-footer">
          	</div>
          </div>
          
 <center>
 <script data-cfasync='false' type='text/javascript' src='//p438449.clksite.com/adServe/banners?tid=438449_858851_0'></script><br>
       <div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
           <center><h6 style="font-family: serif;font-size: 20px; color: white; background: url(https://dhans-project.xyz/7777.jpg); width: 150px; border: 0.1px solid white; border-radius: 3px">OVPN SERVER</h6>
             </center>
          <div class="dev"></div> 
    <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Tipe</th>
<th><font color="white">OpenVPN</th>
</tr>
<tr>
<th><font color="white">Aktif</th>
<th><font color="white">3 Hari</th>
</tr>
<tr>
<th><font color="white">Tersedia</th>
<th><font color="white">3 Server</th>
</tr>
</tbody>
</table>

<div class="dev"></div>
              <a href="ovpn" class="main-button">PILIH</a>
            </div>
          </div>
          </div>
          </div>
                    
             </center>
          
                <div class="col-md-12">
          <div class="sub-footer">
          	</div>
          </div>
          
 <center>
 
       <div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
             	<center><h6 style="font-family: serif;font-size: 20px; color: white; background: url(https://dhans-project.xyz/7777.jpg); width: 150px; border: 0.1px solid white; border-radius: 3px">V2RAY SERVER</h6>
             </center>
          <div class="dev"></div> 
    <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Tipe</th>
<th><font color="white">V2ray</th>
</tr>
<tr>
<th><font color="white">Aktif</th>
<th><font color="white">3 Hari</th>
</tr>
<tr>
<th><font color="white">Tersedia</th>
<th><font color="white">2 Server</th>
</tr>
</tbody>
</table>

<div class="dev"></div>
              <a href="v2ray" class="main-button">PILIH</a>
            </div>
          </div>
          </div>
          </div>
                    
            </center>
          
                <div class="col-md-12">
          <div class="sub-footer">
          	</div>
          </div>
          
 <center>
 
       <div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
             	<center><h6 style="font-family: serif;font-size: 20px; color: white; background: url(https://dhans-project.xyz/7777.jpg); width: 150px; border: 0.1px solid white; border-radius: 3px">TROJAN SERVER</h6>
             </center>
          <div class="dev"></div> 
    <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Tipe</th>
<th><font color="white">Trojan</th>
</tr>
<tr>
<th><font color="white">Aktif</th>
<th><font color="white">3 Hari</th>
</tr>
<tr>
<th><font color="white">Tersedia</th>
<th><font color="white">3 Server</th>
</tr>
</tbody>
</table>

<div class="dev"></div>
              <a href="trojan" class="main-button">PILIH</a>
            </div>
          </div>
          </div>
          </div>
                    
              </center>
          
                <div class="col-md-12">
          <div class="sub-footer">
          	</div>
          </div>
          
          
 <!--
    $ip = $_SERVER['HTTP_CLIENT_IP'];
	$get = json_decode(file_get_contents("https://ipinfo.io/".$ip."/geo", TRUE));
	$kota = $get->city;
	$region = $get->region;
	$country = $get->country;
	$lokasi = $get->loc;
	$pos = $get-postal;
--
    	<center>
          <div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
            <h4>Informasi Anda</h4>
              
             <div class="dev"></div> 
             <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">IP Adress</th>
<th><font color="white">'.$ip.'</th>
</tr>
<tr>
<th><font color="white">Browser</th>
<th><font color="white">'.$ambil_browser().'</th>
</tr>
<tr>
<th><font color="white">Kota</th>
<th><font color="white">'.$city.'</th>
</tr>
<tr>
<th><font color="white">Country</th>
<th><font color="white">'.$country.'</th>
</tr>
<tr>
<th><font color="white">Region</th>
<th><font color="white">'.$region.'</th>
</tr>
<tr>
<th><font color="white">Lokasi</th>
<th><font color="white">'.$lokasi.'</th>
</tr>
<tr>
<th><font color="white">Kode Pos</th>
<th><font color="white">'.$pos.'</th>
</tr>
</tbody>
</table>
<div class="dev"></div>
              
            </div>
          </div>
          </center>
       </center>
-
       
       <div class="col-md-12">
          <div class="sub-footer">
          	</div>
          </div>   -->
          
          
          <div class="features-section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">

          <h2>Kualitas Layanan</h2>
            </div>
          </div>
          <div class="col-md-6">
            <div class="feature-item">
       <!--       <div class="icon">
               <img src="assets/images/feature-01.png" alt="">
              </div>
    -->          <h4>99,99% Waktu Aktif</h4>
              <p>Server kami mendukung jutaan koneksi dengan mudah, jadi Anda tidak perlu khawatir dengan pemutusan sambungan yang mengganggu.</p>
            </div>
          </div>
          
          <div class="col-md-6">
            <div class="feature-item">
      <!--        <div class="icon">
                <img src="assets/images/feature-01.png" alt="">
              </div>
    -->          <h4>Kecepatan Maksimal</h4>
              <p>Kami menggunakan server dengan kecepatan terbaik untuk mendukung kualitas download, streaming, dan kesenangan berselancar anda.</p>
            </div>
          </div>
          
          <div class="col-md-6">
            <div class="feature-item">
 <!--             <div class="icon">
               <img src="assets/images/feature-01.png" alt="">
              </div>
    -->       <h4>Privasi Terjamin</h4>
              <p>Sistem kami dikelola dan dibuat secara independen tanpa mencatat data atau aktivitas pengguna. Jadi informasi Anda tidak pernah sampai ke pihak ketiga.</p>
            </div>
          </div>
          
          <div class="col-md-6">
            <div class="feature-item"> <!--
              <div class="icon">
                <img src="assets/images/feature-01.png" alt="">
              </div>
      -->        <h4>Koneksi Terenkripsi</h4>
              <p>Saat Anda terhubung ke WiFi publik, aktivitas Anda dapat dilacak dan dipantau. Server kami mengenkripsi koneksi Anda agar tetap aman.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Features Ends Here --
     <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2835349828259042"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:block; text-align:center;"
     data-ad-layout="in-article"
     data-ad-format="fluid"
     data-ad-client="ca-pub-2835349828259042"
     data-ad-slot="5428164578"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>             
 -->
        <div class="col-md-12">
          <div class="sub-footer">
           </div></div>  
          
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="footer-item">
              <div class="footer-heading">
                <h2><i class="fa fa-users"></i>  Join Grup Kami</h2>
              </div>
              <ul class="footer-list">
                <li><i class="fa fa-comments-o"></i>  <a href="https://chat.whatsapp.com/IdM2t2pLO2f7JJAvdJ2aY0">WhatsApp</a></li>
                <li><i class="fa fa-comments-o"></i>  <a href="https://t.me/SobatGretong">Telegram</a></li>
                <li><i class="fa fa-comments-o"></i>  <a href="https://t.me/SGDC_TEAM">Telegram</a></li>
                <li><i class="fa fa-comments-o"></i>  <a href="https://t.me/Neza_VPN">Telegram</a></li>
              </ul>
            </div>
          </div>
    
          <div class="col-md-3 col-sm-6 col-xs-12">
            <div class="footer-item">
              <div class="footer-heading">
                <h2><i class="fa fa-phone-square"></i>  Kontak Admin</h2>
              </div>
              <ul class="footer-list">
              	<li><i class="fa fa-envelope-o"></i> <a href="https://wa.me/6282252655313">Dhansss</a></li>
                
                <li><i class="fa fa-envelope-o"></i> <a href="https://wa.me/6283129011845">NezaVPN</a></li>
                
              </ul>
            </div>
          </div> <!--
        <br><br><p style="font-family:serif;color:white;">IP ANDA //<?php //echo  $_SERVER['REMOTE_ADDR']; ?></p>  -->
          <div class="col-md-12">
          <div class="sub-footer">
              <p>Copyright 2021 | <a rel="nofollow" href="https://resselervpnku.tech">DhanZaa Team</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    
 <!--
 function ambil_ip() {
    $ipaddress = '';
    if (!empty($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(!empty($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(!empty($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(!empty($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(!empty($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'Tidak Dikenal';
    return $ipaddress;
}
  
function ambil_browser() {
    $browser = '';
    if(strpos($_SERVER['HTTP_USER_AGENT'], 'Netscape'))
        $browser = 'Netscape';
    else if (strpos($_SERVER['HTTP_USER_AGENT'], 'Firefox'))
        $browser = 'Firefox';
    else if (strpos($_SERVER['HTTP_USER_AGENT'], 'Chrome'))
        $browser = 'Chrome';
    else if (strpos($_SERVER['HTTP_USER_AGENT'], 'Opera'))
        $browser = 'Opera';
    else if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE'))
        $browser = 'Internet Explorer';
    else
        $browser = 'Tidak Diketahui';
    return $browser;
}
?>
-->
    <script src="https://afdhan.github.io/sce/vendor/jquery/jquery.min.js"></script>
    <script src="https://afdhan.github.io/sce/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="https://afdhan.github.io/sce/assets/js/custom.js"></script>
    <script src="https://afdhan.github.io/sce/assets/js/owl.js"></script>
    <script src="https://afdhan.github.io/sce/assets/js/accordions.js"></script>

<script type="text/javascript">
     
     window.onload = function() { jam(); }
   
    function jam() {
     var e = document.getElementById('jam'),
     d = new Date(), h, m, s;
     h = d.getHours();
     m = set(d.getMinutes());
     s = set(d.getSeconds());
   
     e.innerHTML = h +' : '+ m +' : '+ s;
   
     setTimeout('jam()', 1000);
    }
   
    function set(e) {
     e = e < 10 ? '0'+ e : e;
     return e;
    }
     
	const secondHand = document.querySelector('.jarum_detik');
	const minuteHand = document.querySelector('.jarum_menit');
	const jarum_jam = document.querySelector('.jarum_jam');
 
	function setDate(){
		const now = new Date();
 
		const seconds = now.getSeconds();
		const secondsDegrees = ((seconds / 60) * 360) + 90;
		secondHand.style.transform = `rotate(${secondsDegrees}deg)`;
		if (secondsDegrees === 90) {
			secondHand.style.transition = 'none';
		} else if (secondsDegrees >= 91) {
			secondHand.style.transition = 'all 0.05s cubic-bezier(0.1, 2.7, 0.58, 1)'
		}
 
		const minutes = now.getMinutes();
		const minutesDegrees = ((minutes / 60) * 360) + 90;
		minuteHand.style.transform = `rotate(${minutesDegrees}deg)`;
 
		const hours = now.getHours();
		const hoursDegrees = ((hours / 12) * 360) + 90;
		jarum_jam.style.transform = `rotate(${hoursDegrees}deg)`;
	}
 
	setInterval(setDate, 1000)

var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex> slides.length) {slideIndex = 1}    
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 5000); 
}
	


</script>
<script>
(function(__htas){
var d = document,
    s = d.createElement('script'),
    l = d.scripts[d.scripts.length - 1];
s.settings = __htas || {};
s.src = "\/\/apprefaculty.pro\/cMD.9x6Mb\/2H5KlTSrW\/QA9lNiDrIY3fMGjwcg4hMkit0m0_MZjOcJy\/NEzFgwzk";
l.parentNode.insertBefore(s, l);
})({})
</script>
    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; 
      function clearField(t){ 
      if(! cleared[t.id]){ 
          cleared[t.id] = 1;    
          t.value='';  
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>
