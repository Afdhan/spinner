<?php
  //session_start();
 // ob_flush();
  include "con.php";
  $query2 = "UPDATE server SET sisa=25";
  mysqli_query($db, $query2);
  
  
 ?>
