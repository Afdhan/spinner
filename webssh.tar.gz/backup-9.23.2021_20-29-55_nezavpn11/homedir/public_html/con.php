<?php
$dbhost = "localhost";

$dbname = "nezavpn11_base"; 
$dbuser = "nezavpn11_prem"; 
$dbpass = "dhans@%#77"; 

$db = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname); 

 if (!$db) { 
   die("Koneksi gagal");
   } 
   