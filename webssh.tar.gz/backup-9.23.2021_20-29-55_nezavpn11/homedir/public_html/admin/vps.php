<?php
session_start();
ob_flush();
include "../con.php";
$sesi = $_SESSION["username"];
if(empty($sesi)){
  header("Location: /index.php");
}
$query= "select * from admin where kunci='$sesi'";
$hasil = mysqli_query($db, $query);
$anu = mysqli_fetch_assoc($hasil);
if($sesi =! $anu["password"]){
  echo ' <script> window.location.href("index.php"); </script>';
}
?>
 
<form method="post" action="#">
  Nama :
  <p><input type="text" name="nama"></p>
  IP : 
  <p><input type="text" name="ip"></p>
  Username :
  <p><input type="text" name="username"></p>
  Password:
  <p> <input type="password" name="password"></p>
  Domain : 
  <p><input type="text" name="domain"></p>
Limit : 
  <p><input type="text" name="sisa"></p>

  <p>
    
    <input type="submit" name="submit">
  </p>
</form>


<?php
$nama = mysqli_real_escape_string($db, $_POST["nama"]);
$ip = mysqli_real_escape_string($db, $_POST["ip"]);
$user = mysqli_real_escape_string($db, $_POST["username"]);
$pass = mysqli_real_escape_string($db, $_POST["password"]);
$domain = mysqli_real_escape_string($db, $_POST["domain"]);
$limit = mysqli_real_escape_string($db, $_POST["sisa"]);

if(!empty($ip) && !empty($user) && !empty($pass) && !empty($domain) && !empty($limit)){
$query = "insert into server (id, nama, ip, username, password, domain, sisa) value(NULL, '$nama', '$ip', '$user','$pass', '$domain', '$limit')";
$hasil = mysqli_query($db, $query);
if($hasil){
  echo '<script> 
alert("Data VPS Berhasil Disimpan Ke Database.")

</script>';
}else{
  echo '<script> alert("Gagal Memasukan Data VPS Ke Database."); </script>';
}
}
$query = "select * from server limit 10";
$hasil = mysqli_query($db, $query);

?>
<table class="table"> <thead> <tr>  <th scope="col">ID </th><th scope="col">Nama </th> <th scope="col">Domain </th> <th scope="col">IP </th> <th scope="col">Username</th> <th scope="col">Password</th> <th scope="col">Action</th> </tr> </thead> <tbody></tbody>

<?php
while($data = mysqli_fetch_array($hasil)){
     $id = $data["id"];
  $domain = $data["domain"];
  $nama = $data["nama"];
  $ip = $data["ip"];
  $user = $data["username"];
  $pass = $data["password"];
echo '<tr><th scope="col">'.$id.' </th><th scope="col">'.$nama.' </th>  <th scope="col">'.$domain.' </th> <th scope="row">'.$ip.'</th> <td>'.$user.'</td> <td>'.$pass.' </td> <td><a href="?del='.$ip.'"> Delete </a></td> </tr>';

}
echo "</tbody> </table>";

if(!empty($_GET["del"])){
  $del = $_GET["del"];
   $query = "delete from server where ip='$del'";
   if(mysqli_query($db, $query)){
     echo '<script> alert("Berhasil Menghapus VPS Dari Database");
     window.location.href("vps.php");
     </script> ';
   }
  
}


?>
