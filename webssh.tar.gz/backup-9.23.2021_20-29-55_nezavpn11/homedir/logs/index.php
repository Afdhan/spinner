<?php
  session_start();
  ob_flush();
  include "../con.php";
  ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Free SSH Premium">
    <meta name="author" content="DhansProject">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">

    <title>Free Premium VPN DhanZaa Project</title>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
 
    <link href="https://afdhan.github.io/sce/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 <link rel="icon" href="https://raw.githubusercontent.com/Afdhan/spinner/main/999.png" height="330px" width="350px" type="image/jpg">

    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/fontawesome.css">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/begrond.css">
    <link rel="stylesheet" href="https://afdhan.github.io/sce/assets/css/owl.css">
	  
</head>
  
  <body>
  	<!-- Header -->
    <header class="" style="background: url(https://dhans-project.xyz/7777.jpg);background-size: cover;">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.html"><h2>Dhans X NezaVPN<!-- <em>TEAM</em>--></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
           <span class="navbar-toggler-icon" style="color:white"></span> 
          </button>
          <div class="collapse navbar-collapse" style="background: url(https://dhans-project.xyz/7777.jpg);background-size: cover;" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
             <li class="nav-item">
                <a class="nav-link" href="../"><font  color="white"><strong>Halaman Utama</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/ssh"><font  color="white"><strong>SSH Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/ovpn"><font  color="white"><strong>OpenVPN Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/v2ray"><font  color="white"><strong>V2Ray Server</font></strong></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/trojan"><font  color="white"><strong>Trojan Server</font></strong></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>	
  <footer>
       <center>
                     
            <!--IKLAN GOOGLE-->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2835349828259042"
     crossorigin="anonymous"></script>         	
   
  <!--IKLAN ADSTERA-->
  <script type='text/javascript' src='//stammerail.com/41/3b/e8/413be8cfb539990db6aa2bd09bde2bb6.js'></script>
  
       	<div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
           <center><h6 style="font-family: serif;font-size: 20px; color: white; background: url(https://dhans-project.xyz/7777.jpg); width: 150px; border: 0.1px solid white; border-radius: 3px">SSH SERVER</h6>
             </center>
          <div class="dev"></div> <div class="table-responsive-lg">
    <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Tipe</th>
<th><font color="white">SSH</th>
</tr>
<tr>
<th><font color="white">ISP</th>
<th><font color="white">Azure</th>
</tr>
<tr>
<th><font color="white">Country</th>
<th><font color="white">Singapore</th>
</tr>
<tr>
<th><font color="white">Region</th>
<th><font color="white">SG</th>
</tr>
</tbody>
</table></div>

<div class="dev"></div>
              <a href="ssh-azure" class="main-button">BUAT</a>
            </div>
          </div>
          </div>
          </div>
                    
            <!--IKLAN -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2835349828259042"
     crossorigin="anonymous"></script>         	
   
          </center>
          
          <div class="col-md-12">
          <div class="sub-footer">
          	</div>
          </div>      
       	       <center>
       	<div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
           <center><h6 style="font-family: serif;font-size: 20px; color: white; background: url(https://dhans-project.xyz/7777.jpg); width: 150px; border: 0.1px solid white; border-radius: 3px">SSH SERVER</h6>
             </center>
          <div class="dev"></div> <div class="table-responsive-lg">
    <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Tipe</th>
<th><font color="white">SSH</th>
</tr>
<tr>
<th><font color="white">ISP</th>
<th><font color="white">AWS Amazon</th>
</tr>
<tr>
<th><font color="white">Country</th>
<th><font color="white">Singapore</th>
</tr>
<tr>
<th><font color="white">Region</th>
<th><font color="white">SG</th>
</tr>
</tbody>
</table></div>

<div class="dev"></div>
              <a href="ssh-aws" class="main-button">BUAT</a>
            </div>
          </div>
          </div>
          </div>
                    
            <!--IKLAN -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2835349828259042"
     crossorigin="anonymous"></script>         	
   
          </center>
          
          <div class="col-md-12">
          <div class="sub-footer">
          	</div>
          </div>
          
 <center>
       	<div class="col-md-4 col-sm-6 col-xs-12">
             <div class="pricing-item">
           <center><h6 style="font-family: serif;font-size: 20px; color: white; background: url(https://dhans-project.xyz/7777.jpg); width: 150px; border: 0.1px solid white; border-radius: 3px">SSH SERVER</h6>
             </center>
          <div class="dev"></div> <div class="table-responsive-lg">
    <table class="table table-bordered" style="background: url(https://dhans-project.xyz/7777.jpg)"; width="100%" cellspacing="0">
<tbody>
<tr>
<th><font color="white">Tipe</th>
<th><font color="white">SSH</th>
</tr>
<tr>
<th><font color="white">ISP</th>
<th><font color="white">Linode</th>
</tr>
<tr>
<th><font color="white">Country</th>
<th><font color="white">Singapore</th>
</tr>
<tr>
<th><font color="white">Region</th>
<th><font color="white">SG</th>
</tr>
</tbody>
</table></div>

<div class="dev"></div>
              <a href="ssh-linode" class="main-button">BUAT</a>
            </div>
          </div>
          </div>
          </div>
                    
            <!--IKLAN -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2835349828259042"
     crossorigin="anonymous"></script>         	
   
          </center>
       
       <div class="col-md-12">
          <div class="sub-footer">
              <p>Copyright 2021 | <a rel="nofollow" href="https://resselervpnku.tech">DhanZaa Team</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
    

    <script src="https://afdhan.github.io/sce/vendor/jquery/jquery.min.js"></script>
    <script src="https://afdhan.github.io/sce/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="https://afdhan.github.io/sce/assets/js/custom.js"></script>
    <script src="https://afdhan.github.io/sce/assets/js/owl.js"></script>
    <script src="https://afdhan.github.io/sce/assets/js/accordions.js"></script>

<script type="text/javascript">
function copy_non() {
        document.getElementById("non").select();
        document.execCommand("copy");
        alert("Payload Berhasil Dicopy Ke Clipboard!");
    }
    </script>
    <script language = "text/Javascript"> 
    
      cleared[0] = cleared[1] = cleared[2] = 0; 
      function clearField(t){ 
      if(! cleared[t.id]){ 
          cleared[t.id] = 1;  
          t.value=''; 
          t.style.color='#fff';
          }
      }
    </script>

  </body>
</html>
